<?php get_header(); ?>
<main id="main" role="main">
	<?php get_template_part('templates/post/single-content'); ?>
</main>
<?php get_footer(); ?>
