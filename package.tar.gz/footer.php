<footer id="footer" class="main-footer bg-black" role="contentinfo">
	<?php get_template_part("template-parts/footer/footer-nav"); ?>
	<?php get_template_part("template-parts/footer/footer-copyright"); ?>
</footer>

<div id="background-shapes-parent" class="background-shapes">
	<div class="background-shapes-container">
		<figure class="top-page">
			<img src="<?= get_template_directory_uri() . "/assets/img/background-shape.png" ?>" />
		</figure>
		<figure class="mid-page">
			<img src="<?= get_template_directory_uri() . "/assets/img/background-shape.png" ?>" />
		</figure>
		<figure id="bottom-page-shape" class="bottom-page">
			<img src="<?= get_template_directory_uri() . "/assets/img/background-shape.png" ?>" />
		</figure>
	</div>
</div>
</div>

<?php get_template_part("template-parts/mobile/mobile-navigation"); ?>
<?php wp_footer(); ?>

</body>

</html>
