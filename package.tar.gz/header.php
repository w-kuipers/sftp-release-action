<?php
$company_info = get_field("global_info", "option")["company_info"];
$whatsapp = $company_info["whatsapp"];
?>


<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php do_action('wp_body_open'); ?>

	<header class="main-header" role="banner">
		<?php get_template_part('template-parts/header/nav-bar'); ?>
	</header>
	<div class="backdrop"></div>

	<?php if ($whatsapp): ?>
		<div class="wrap large fixed-whatsapp">
			<a href="https://wa.me/<?= $whatsapp ?>"><?= render_svg_icon("", "whatsapp"); ?><span><?= $whatsapp ?></span></a>
		</div>
	<?php endif; ?>

	<div class="page-container">
