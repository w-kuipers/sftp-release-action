<?php

// Add menu support to theme
if (function_exists('add_theme_support')) :

	add_theme_support('nav-menus');
	add_theme_support('menus');
	add_theme_support('post-thumbnails');
	load_theme_textdomain('dtch', get_template_directory() . '/languages');

endif;


// ACF customs
if (class_exists('ACF')) {
	require_once(get_template_directory() . '/includes/plugins/acf.php');
}

// Yoast SEO customs
if (class_exists('WPSEO_Frontend')) {
	require_once(get_template_directory() . '/includes/plugins/yoast.php');
}

// Gravityforms customs
if (class_exists('GFForms')) {
	require_once(get_template_directory() . '/includes/plugins/gravity-forms.php');
}

// Register the shortcodes
require_once(get_template_directory() . '/includes/shortcodes.php');

if (class_exists('DD_Custom_Shortcodes')) {
	new DD_Custom_Shortcodes();
}

require_once(get_template_directory() . '/includes/setup.php');
require_once(get_template_directory() . '/includes/apis.php');
require_once(get_template_directory() . '/includes/cpt.php');
require_once(get_template_directory() . '/includes/enqueue.php');
require_once(get_template_directory() . '/includes/images.php');
require_once(get_template_directory() . '/includes/options.php');
require_once(get_template_directory() . '/includes/comments.php');
require_once(get_template_directory() . '/includes/roles.php');
require_once(get_template_directory() . '/includes/widgets-menus.php');
require_once(get_template_directory() . '/includes/wysiwyg.php');
require_once(get_template_directory() . '/includes/xss-protection.php');
require_once(get_template_directory() . '/includes/utils.php');
require_once(get_template_directory() . '/includes/table-of-contents.php');


// Check if WooCommerce is active and add default changes
if (class_exists('WooCommerce')) {
	require_once(get_template_directory() . '/includes/woocommerce/index.php');
}
