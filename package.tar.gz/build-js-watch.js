const concat = require('concat');
const uglifyJS = require('uglify-js');
const chokidar = require('chokidar');
const fs = require('fs');
const path = require('path');
const debounce = require('lodash.debounce');

const jsDirectory = path.join(__dirname, '_src/js');
const outputDir = path.join(__dirname, 'assets/js');
const outputFile = path.join(outputDir, 'main.js');
const outputMapFile = path.join(outputDir, 'main.js.map'); 

function findAllJsFiles(dir, fileList = []) {
    const files = fs.readdirSync(dir);

    files.forEach(file => {
        const filePath = path.join(dir, file);
        const fileStat = fs.statSync(filePath);

        if (fileStat.isDirectory()) {
            findAllJsFiles(filePath, fileList);
        } else if (filePath.endsWith('.js')) {
            fileList.push(filePath);
        }
    });

    return fileList;
}

const concatAndMinifyJs = debounce(() => {

    try {

        const files = findAllJsFiles(jsDirectory);

        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        concat(files).then(result => {

            const minified = uglifyJS.minify(result, {
                sourceMap: {
                    filename: 'main.js',
                    url: 'main.js.map'
                }
            });

            if (minified.error) {
                console.error('Error minifying JS:', minified.error);
                return;
            }

            fs.writeFileSync(outputFile, minified.code);

            if (minified.map) {
                fs.writeFileSync(outputMapFile, minified.map);
            }

            console.log('JS concatenated and minified successfully.');
            
        }).catch(error => {
            console.error('Error during JS concatenation/minification:', error);
        });
    
    } catch (error) {

        console.error('Error processing JavaScript files:', error);

    }

}, 300);

const watcher = chokidar.watch(jsDirectory, {
    ignored: path.join(__dirname, 'assets/**'),
    persistent: true,
});

watcher
    .on('add', concatAndMinifyJs)
    .on('change', concatAndMinifyJs)
    .on('unlink', concatAndMinifyJs);

console.log('Watching JS files for changes...');