<?php 
if ( class_exists('ACF') ) {

	if( have_rows('flex_content') ) :

	    while ( have_rows( 'flex_content' ) ) : the_row();

	    	get_template_part('template-parts/flexible/rows/' . get_row_layout() );

	    endwhile;
	    
	endif; 
	
}
?>