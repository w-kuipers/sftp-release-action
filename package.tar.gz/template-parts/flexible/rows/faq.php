<?php
$content = get_field("faq", "option");
?>

<section class="faq spacing-row">
	<div class="wrap small">
		<div class="accordion-list">

			<?php foreach ($content["item"] as $item): ?>
				<div data-accordion-count="<?= $accordion_count ?>" class="accordion-item">
					<p class="accordion-trigger">
						<span><?= $item["question"] ?></span>
						<?= render_svg_icon("", "chevron-down"); ?>
					</p>
					<p class="accordion-content"><?= $item["answer"] ?></p>
				</div>
			<?php endforeach; ?>

		</div>
	</div>
</section>
