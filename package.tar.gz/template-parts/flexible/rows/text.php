<?php
$group = get_sub_field("text");
$title = $group["title"];
$title_id = indexable_title($title);
$content = indexable_content($group["content"]);
?>

<section class="section text spacing-row">
	<div class="wrap">
		<div class="text-container <?= $group["background_color"] ?>">

			<?php if ($title): ?>
				<div class="section__header">
					<h2 id="<?= $title_id; ?>" class="section__title"><?= $title; ?></h2>
				</div>
			<?php endif; ?>

			<?php if ($content): ?>
				<div class="section__content">
					<?= $content; ?>
				</div>
			<?php endif; ?>

			<?php if ($group["cta"]): ?>
				<div class="cta-container">
					<?php $cta_count = 0; ?>
					<?php foreach ($group["cta"] as $cta): ?>
						<a href="<?= $cta["link"]["url"] ?>" target="<?= $cta["link"]["target"] ?>" class="button <?= $cta_count > 0 ? "black" : "" ?>"><?= $cta["link"]["title"] ?></a>
						<?php $cta_count++; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
