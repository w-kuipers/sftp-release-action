<?php
$group = get_sub_field("media");
$title = $group["title"];
$title_id = indexable_title($title);
$content = indexable_content($group["content"]);
$media_type = $group["type"];
?>

<section class="media spacing-row">
	<div class="wrap">

		<div class="media-container <?php echo $group["background_color"] ?>">
			<?php if ($title): ?>
				<div class="section__header">
					<h2 id="<?= $title_id ?>" class="section__title <?= $title_color; ?>"><?= $title; ?></h2>

					<?php if ($content): ?>
						<div class="section__content">
							<?= $content; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="media__content">
				<?php if ($media_type === "image"): ?>
					<figure><?= wp_get_attachment_image($group["image"], "large", false, ["class" => "lazy"]) ?></figure>
				<?php endif; ?>

				<?php if ($media_type === "video"): ?>
					<?= do_shortcode('[embed-video-image url="' . $group["video_embed_url"] . '" img_id="' . $group["video_thumbnail"] . '"]'); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
