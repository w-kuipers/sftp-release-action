<?php
if (isset($args["content"])) {
	$content = $args["content"];
} else {
	$content = get_sub_field("featured_blogs");
}

$archive_link = get_permalink(get_option("page_for_posts"));

$blogs = new WP_Query(array(
	"posts_per_page" => 3,
	"orderby" => "date",
	"order" => "DESC",
));
?>

<?php if ($blogs->have_posts()): ?>
	<?php if (!wp_is_mobile()): ?>
		<section class="featured-blogs spacing-row">
			<div class="wrap">

				<h2><?= $content["title"] ?></h2>
				<div class="posts-container">
					<?php while ($blogs->have_posts()): $blogs->the_post() ?>
						<a href="<?= get_the_permalink() ?>" class="post">
							<figure class="wrap-16-9">
								<?php foreach (get_the_category() as $category): ?>
									<div class="badge"><?= render_svg_icon("", "tag") ?><?= $category->name ?></div>
								<?php endforeach; ?>
								<?= wp_get_attachment_image(get_post_thumbnail_id(), "large", false, array("class" => "lazy")); ?>
							</figure>

							<div class="content">
								<p class="title"><?= the_title() ?></p>
								<p class="excerpt"><?= max_length(get_the_excerpt()); ?></p>
								<button class="button black"><?= __("Read more", "dtch"); ?></button>
							</div>
						</a>
					<?php endwhile; ?>
				</div>

				<a href="<?= $archive_link ?>" class="button outline"><?= __("Complete blog overview", "dtch") ?></a>
			</div>
		</section>
	<?php endif; ?>

	<?php if (wp_is_mobile()): ?>
		<section class="featured-blogs spacing-row">
			<div class="wrap">
				<h2><?= $content["title"] ?></h2>
				<div class="featured-blogs-slider">
					<div class="swiper-wrapper">
						<?php while ($blogs->have_posts()): $blogs->the_post() ?>
							<div class="swiper-slide post">
								<figure class="wrap-16-9">
									<?php foreach (get_the_category() as $category): ?>
										<div class="badge"><?= render_svg_icon("", "tag") ?><?= $category->name ?></div>
									<?php endforeach; ?>
									<?= wp_get_attachment_image(get_post_thumbnail_id(), "large", false, array("class" => "lazy")); ?>
								</figure>

								<div class="content">
									<p class="title"><?= the_title() ?></p>
									<p class="excerpt"><?= max_length(get_the_excerpt()); ?></p>
									<a href="<?= get_the_permalink() ?>" class="button black"><?= __("Read more", "dtch"); ?></a>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
<?php endif; ?>
