<?php

if (isset($args["content"])) {
	$content = $args["content"];
} else {
	$content = get_sub_field("featured_products");
}
$products = new WP_Query(array(
	"posts_per_page" => 3,
	"orderby" => "date",
	"order" => "DESC",
	"post_status" => "publised",
	"post_type" => "printer"
));
?>

<?php if ($products->have_posts()): ?>
	<section class="featured-products spacing-row">
		<div class="wrap">
			<h2><?= $content["title"] ?></h2>

			<?php if (!wp_is_mobile()): ?>
				<div class="products-container">
					<?php while ($products->have_posts()): $products->the_post() ?>
						<div class="product">
							<p class="title"><?= get_the_title(); ?></p>
							<figure class="wrap-square">
								<?= wp_get_attachment_image(get_post_thumbnail_id(), "large", false, array("class", "lazy")); ?>
							</figure>
							<p class="excerpt"><?= max_length(get_field("short_description")); ?></p>
							<a href="#" class="button external black"><?= __("Go to the product", "dtch") ?></a>
						</div>
					<?php endwhile; ?>
				</div>
			<?php endif; ?>

			<?php if (wp_is_mobile()): ?>
				<div class="featured-products-slider">
					<div class="swiper-wrapper">
						<?php while ($products->have_posts()): $products->the_post() ?>
							<div class="swiper-slide product">
								<p class="title"><?= get_the_title(); ?></p>
								<figure class="wrap-square">
									<?= wp_get_attachment_image(get_post_thumbnail_id(), "large", false, array("class", "lazy")); ?>
								</figure>
								<p class="excerpt"><?= max_length(get_field("short_description")); ?></p>
								<a href="#" class="button external black"><?= __("Go to the product", "dtch") ?></a>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			<?php endif; ?>


			<div class="button-container">
				<a class="button outline"><?= __("See all products", "dtch"); ?></a>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php wp_reset_postdata() ?>
