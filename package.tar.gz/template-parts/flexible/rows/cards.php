<?php
$content = get_sub_field("cards");
?>

<section class="cards spacing-row">
	<div class="wrap">
		<h2><?= $content["title"] ?></h2>

		<?php if (!wp_is_mobile()): ?>
			<div class="cards-container">
				<?php foreach ($content["items"] as $item): ?>
					<div class="card">
						<p class="title"><?= $item["title"]; ?></p>
						<figure class="wrap-square">
							<?= wp_get_attachment_image($item["image"], "large", false, array("class", "lazy")); ?>
						</figure>
						<p class="excerpt"><?= max_length($item["description"]); ?></p>
						<a href="#" class="button external black"><?= __("Go to the product", "dtch") ?></a>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if (wp_is_mobile()): ?>
			<div class="cards-slider">
				<div class="swiper-wrapper">
					<?php foreach ($content["items"] as $item): ?>
						<div class="card swiper-slide">
							<p class="title"><?= $item["title"]; ?></p>
							<figure class="wrap-square">
								<?= wp_get_attachment_image($item["image"], "large", false, array("class", "lazy")); ?>
							</figure>
							<p class="excerpt"><?= max_length($item["description"]); ?></p>
							<a href="#" class="button external black"><?= __("Go to the product", "dtch") ?></a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>


		<div class="button-container">
			<a class="button outline"><?= __("See all products", "dtch"); ?></a>
		</div>
	</div>
</section>
