<?php
$content = get_sub_field("slider");
?>

<section class="slider spacing-row">
	<div class="wrap">
		<div class="slider-head">
			<h2><?= $content["title"] ?></h2>
			<p class="subtitle"><?= $content["subtitle"] ?></p>

		</div>
		<div class="flex-slider">
			<div class="swiper-wrapper">
				<?php foreach ($content["slides"] as $slide): ?>
					<div class="swiper-slide">
						<figure class="slide wrap-16-9 <?= $slide["brand_color"] ?>">
							<?= wp_get_attachment_image($slide["background-image"], "large", false, array("class" => "lazy")); ?>

							<div class="content">
								<div class="content-head">
									<figure>
										<?= wp_get_attachment_image($slide["image"], "medium", false, array("class" => "lazy")); ?>
									</figure>

									<div class="content-head-text">
										<p><?= $slide["subtitle"] ?></p>
										<a href="<?= $slide["button"]["link"]["url"] ?>" class="button black"><?= $slide["button"]["title"] ?></a>
									</div>
								</div>
								<h3><?= $slide["title"] ?></h3>	
							</div>
						</figure>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
