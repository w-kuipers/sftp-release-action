<?php
$content = get_sub_field("categories");
$categories = get_categories(array(
    "taxonomy" => "printer-category",
    "hide_empty" => false,
    "orderby" => "name",
    "order" => "DESC"
));
?>

<?php if (!wp_is_mobile()): ?>
	<section class="categories spacing-row">
		<div class="wrap">
			<div class="categories-card">
				<div class="categories-head">
					<h2><?= $content["title"] ?></h2>
					<p><?= $content["subtitle"] ?></p>
				</div>

				<div class="categories-items">
					<?php for ($c = 0; $c < count($categories); $c++): ?>
						<a href="#" class="categories-items-item desktop-item <?= get_field("brand_color", $categories[$c]) ?>">
							<figure class="logo">
								<?= wp_get_attachment_image(get_field("logo", $categories[$c]), "thumbnail", false, array("class" => "lazy")); ?>
							</figure>
							<figure class="image">
								<?= wp_get_attachment_image(get_field("image", $categories[$c]), "large", false, array("class" => "lazy")); ?>
							</figure>
							<div class="content">
								<p class="title"><?= $categories[$c]->name ?></p>
								<p class="description"><?= get_field("short_description", $categories[$c]) ?></p>
								<button class="button"><?= __("Read more", "dtch") ?></button>
							</div>
						</a>
					<?php endfor; ?>
				</div>

				<?php if ($content["cta-button"]): ?>
					<div class="categories-foot">
						<?php if ($content["cta-image"]): ?>
							<figure>
								<?= wp_get_attachment_image($content["cta-image"], "thumbnail", false, array("class" => "lazy")); ?>
							</figure>
						<?php endif; ?>

						<?php if ($content["cta-title"]): ?>
							<p><?= $content["cta-title"] ?></p>
						<?php endif; ?>

						<a class="button" href="<?= $content["cta-button"]["url"] ?>" target="<?= $content["cta-button"]["target"] ?>"><?= $content["cta-button"]["title"] ?></a>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php if (wp_is_mobile()): ?>
	<section class="categories spacing-row">
		<div class="wrap">
			<div class="categories-card">
				<div class="categories-head">
					<h2><?= $content["title"] ?></h2>
				</div>

				<div class="categories-slider">
					<div class="categories-items swiper-wrapper">
						<?php for ($c = 0; $c < count($categories); $c++): ?>
							<div class="swiper-slide categories-items-item active <?= get_field("brand_color", $categories[$c]) ?>">
								<figure class="logo">
									<?= wp_get_attachment_image(get_field("logo", $categories[$c]), "thumbnail", false, array("class" => "lazy")); ?>
								</figure>
								<figure class="image">
									<?= wp_get_attachment_image(get_field("image", $categories[$c]), "large", false, array("class" => "lazy")); ?>
								</figure>
								<div class="content">
									<p class="title"><?= $categories[$c]->name ?></p>
									<p class="description"><?= get_field("short_description", $categories[$c]) ?></p>
									<a href="#" class="button"><?= __("Read more", "dtch") ?></a>
								</div>
							</div>
						<?php endfor; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
