<?php
$content = get_sub_field("accordion");
$image_count = 0;
$accordion_count = 0;
?>

<section class="accordion-block spacing-row">
	<div class="wrap">
		<div class="accordion-block-content">
			<h2><?= $content["title"] ?></h2>
			<div>
				<?= $content["content"] ?>
			</div>
		</div>	

		<div class="accordion-block-loop">
			<div class="accordion-block-images">
				<?php foreach($content["items"] as $item): ?>
					<figure data-image-count="<?= $image_count ?>" class="wrap-square accordion-block-image">
						<?= wp_get_attachment_image($item["image"], "large", false, array("class" => "lazy")); ?>	
					</figure>	
					<?php $image_count++ ?>
				<?php endforeach; ?>
			</div>
			<div class="accordion-block-items">
				<h2><?= $content["accordion-title"] ?></h2>
				<div class="accordion-list">
					<?php foreach($content["items"] as $item): ?>
						<div data-accordion-count="<?= $accordion_count ?>" class="accordion-block-item accordion-item">
							<p class="accordion-trigger">
								<?= $item["title"] ?>
								<?= render_svg_icon("", "chevron-down"); ?>
							</p>	
							<p class="accordion-content"><?= $item["description"] ?></p>	
						</div>	
						<?php $accordion_count++ ?>
					<?php endforeach; ?>
				</div>	
			</div>	
		</div>	
	</div>
</section>
