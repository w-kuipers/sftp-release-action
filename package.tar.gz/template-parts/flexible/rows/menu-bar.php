<?php
$content = get_sub_field("menu_bar");
?>

<section class="menu-bar spacing-row">
	<div class="wrap">
		<?php if ($content["title"]): ?>
			<p class="title"><?= $content["title"] ?></p>
		<?php endif; ?>

		<ul class="links">
			<?php $link_count = count($content["links"]); ?>
			<?php foreach ($content["links"] as $key => $link): ?>
				<li><a href="<?= $link["link"]["url"] ?>">
					<?= $link["link"]["title"] ?>
					<?= render_svg_icon("", "chevron-right"); ?>
				</a></li>

				<?php if ($key < $link_count - 1): ?>
					<span class="separator">|</span>
				<?php endif; ?>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
