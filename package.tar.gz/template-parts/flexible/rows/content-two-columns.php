<?php
$group = get_sub_field("content-two-columns");
$title = $group["title"];
$title_id = indexable_title($title);
$reversed_order = $group["reversed_order"];


// See if an image/video block is included
$has_media = false;
foreach (array("left", "right") as $block) {
	if ($group[$block]["content_type"] == "image" || $group[$block]["content_type"] == "video") {
		$has_media = true;
	}
}

// See if both left and right are media blocks
$both_media = false;
if (($group["left"]["content_type"] == "image" || $group["left"]["content_type"] == "video") && ($group["right"]["content_type"] == "image" || $group["right"]["content_type"] == "video")) {
	$both_media = true;
}

$classes = concat_classes(
	$reversed_order ? "reversed" : null,
	$has_media ? "has-media" : null,
	$both_media ? "both-media" : null,
);
?>

<section class="section content-two-columns spacing-row <?php echo $classes; ?>">
	<div class="wrap">
		<div class="ctc-container <?php echo $group["background_color"] ?>">

			<?php if ($title) : ?>
				<div class="section__header">
					<h2 id="<?= $title_id ?>" class="section__title"><?php echo $title; ?></h2>
				</div>
			<?php endif; ?>

			<div class="col-2-grid">
				<?php foreach (array("left", "right") as $block): ?>
					<div class="section__content <?= $block ?> <?= $has_media ? "has-media" : "" ?>">
						<?php
						$content = indexable_content($group[$block]);
						$type = $content["content_type"];
						?>

						<?php if ($type === "text" && $content["content"]) : ?>
							<?php echo $content["content"]; ?>
							<?php if ($content["cta"]) : ?>
								<div class="cta-container">
									<?php $cta_count = 0; ?>
									<?php foreach ($content["cta"] as $cta): ?>
										<a href="<?php echo $cta["link"]["url"] ?>" target="<?php echo $cta["link"]["target"] ?>" class="button <?php echo $cta_count > 0 ? "black" : "" ?>"><?php echo $cta["link"]["title"] ?></a>
										<?php $cta_count++; ?>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						<?php endif; ?>

					</div>
				<?php endforeach; ?>

			</div>
		</div>
	</div>
	<div class="wrap large <?= $has_media ? "" : "hidden" ?>">
		<div class="ctc-container <?php echo $group["background_color"] ?>">
			<div class="col-2-grid">
				<?php foreach (array("left", "right") as $block): ?>
					<div class="section__content <?= $block ?>">
						<?php
						$content = $group[$block];
						$type = $content["content_type"];
						?>

						<?php if ($both_media): ?>
							<div class="media-container">
							<?php endif; ?>

							<?php if ($type === "image" && $content["image"]) : ?>
								<figure class="<?= $both_media ? "wrap-16-9" : null ?>"><?php echo wp_get_attachment_image($content["image"], "large", false, ["class" => "lazy"]) ?></figure>
							<?php endif; ?>

							<?php if ($type === "video" && $content["video_embed_url"]) : ?>
								<figure class="<?= $both_media ? "wrap-16-9" : null ?>"><?php echo do_shortcode('[embed-video-image url="' . $content["video_embed_url"] . '" img_id="' . $content["video_thumbnail"] . '"]'); ?></figure>
							<?php endif; ?>

							<?php if ($both_media): ?>
							</div>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
