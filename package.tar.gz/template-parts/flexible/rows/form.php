<?php
if (isset($args["content"])) {
	$content = $args["content"];
} else {
	$content = get_sub_field("form");
}

$title = $content["title"];
$title_id = indexable_title($title);
?>

<section class="form spacing-row">
	<div class="wrap">
		<div class="form-container">
			<h2 id="<?= $title_id ?>"><?= $content["title"] ?></h2>
			<div class="description-container">
				<p class="description"><?= $content["description"] ?></p>
				<p class="subtitle"><?= $content["subtitle"] ?></p>
			</div>
			<?= do_shortcode("[gravityform id='" . $content["form"] . "' title='false' description='false']"); ?>
		</div>
	</div>
</section>
