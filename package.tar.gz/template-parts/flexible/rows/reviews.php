<?php
$content = get_field("reviews", "option")["reviews"];
?>

<section class="reviews spacing-row">
	<div class="wrap">
		<div class="reviews-head">
			<div class="title-wrap">
				<?php get_template_part("template-parts/global/reviews-trustmark"); ?>
				<h2><?= $content["title"] ?></h2>
			</div>
			<p class="subtitle"><?= $content["subtitle"] ?></p>
		</div>
	</div>

	<div class="slider-wrap">
		<div class="wrap">
			<div class="review-slider">
				<div class="swiper-wrapper">
					<?php foreach ($content["reviews"] as $review): ?>
						<div class="swiper-slide">
							<p class="title"><?= $review["title"] ?></p>
							<div class="score-container">
								<?= do_shortcode("[stars score='" . $review["score"] . "']"); ?>
								<p><?= $review["date"] ?></p>
							</div>

							<p class="message"><?= $review["message"] ?></p>

							<p class="author">
								<span><?= $review["name"] ?></span>
								<?php if ($review["job"]): ?>
									<span>|</span>
									<span><?= $review["job"] ?></span>
								<?php endif; ?>	
							</p>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="review-slider-navigation">
					<div class="review-slider-prev review-slider-navigation-button"><?= render_svg_icon("", "chevron-left"); ?></div>
					<div class="review-slider-next review-slider-navigation-button"><?= render_svg_icon("", "chevron-right"); ?></div>
				</div>	
			</div>
		</div>
	</div>
</section>
