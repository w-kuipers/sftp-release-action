<?php
if (isset($args["content"])) {
	$content = $args["content"];
} else {
	$content = get_sub_field("image_cards");
}
?>

<section class="image-cards spacing-row">
	<div class="wrap">
		<h2><?= $content["title"] ?></h2>

		<div class="image-card-items">
			<?php foreach ($content["cards"] as $card): ?>
				<?php if ($card["button"]): ?>
					<a href="<?= $card["button"]["link"] ?>" class="image-card-item">
						<?= wp_get_attachment_image($card["image"], "large", false, array("class" => "lazy")); ?>
						<div class="content desktop">
							<p class="title"><?= $card["title"] ?></p>
							<p class="description"><?= $card["description"] ?></p>
							<button class="button black"><?= $card["button"]["title"] ?></button>
						</div>
					</a>
					<div class="content mobile">
						<p class="title"><?= $card["title"] ?></p>
						<p class="description"><?= $card["description"] ?></p>
						<button class="button black"><?= $card["button"]["title"] ?></button>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
