<?php if (function_exists("yoast_breadcrumb")) : ?>
	<div class="breadcrumbs">
		<div class="wrap">
			<?php yoast_breadcrumb("<p class='breadcrumbs__text smaller'>", "</p>"); ?>
		</div>
	</div>
<?php endif; ?>
