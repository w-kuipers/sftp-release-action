<?php
$global_info = get_field("global_info", "option");
$social_media = $global_info["social_media"];
?>

<?php if ($social_media): ?>
	<ul class="social-media-icons">
		<?php foreach ($social_media as $item): ?>
			<li><a href="<?= $item["url"] ?>" target="_blank"><?= render_svg_icon("", $item["network"]) ?></a></li>
		<?php endforeach ?>
	</ul>
<?php endif; ?>
