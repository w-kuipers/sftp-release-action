<?php
$menu = array(
	"theme_location" => "language-navigation",
	"container_class" => "language-switch__menu"
);

$language = get_bloginfo('language');
$lang_arr = explode('-', $language);
?>

<div class="language-switch">
	<button class="language-switch__button" title="<?php _e('Show other languages', 'dtch'); ?>">
		<?php echo render_svg_icon("flag", $lang_arr[0]) ?>
		<?php echo render_svg_icon("", "chevron-down") ?>

	</button>
	<?php //wp_nav_menu($menu); 
	?>
</div>
