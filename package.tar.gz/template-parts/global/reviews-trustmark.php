<?php
$trustmark_options = get_field("trustmarks", "option");
?>

<div class="reviews-trustmark">
	<?php if ($trustmark_options["trustmark-logo"]): ?>
		<figure>
			<?= wp_get_attachment_image($trustmark_options["trustmark-logo"], "small"); ?>
		</figure>
	<?php endif; ?>

	<?php if ($trustmark_options["score"]): ?>
		<?= do_shortcode("[stars score='" . $trustmark_options["score"] * 2 . "']"); ?>
		<p class="reviews-trustmark-score"><?= $trustmark_options["score"] ?></p>
	<?php endif; ?>

	<?php if ($trustmark_options["review-amount"]): ?>
		<p class="reviews-trustmark-amount">(<?= $trustmark_options["review-amount"] ?>)</p>
	<?php endif; ?>
</div>
