<?php 
	global $wp_query; 
	if( $wp_query->max_num_pages && $wp_query->max_num_pages > 1 ) :
?>

<nav class="pagination" role="navigation" aria-label="<?php esc_attr_e( __('Pagination navigation', 'dtch') ); ?>">

	<?= paginate_links( array(
		'base'			=> str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
		'format'		=> '/page/%#%/',
		'current'		=> max( 1, get_query_var('paged') ),
		'total'			=> $wp_query->max_num_pages,
		'prev_text'     => render_svg_icon('', 'chevron-left'),
		'next_text'     => render_svg_icon('', 'chevron-right')						
	) ); ?>

</nav>

<?php endif; ?>