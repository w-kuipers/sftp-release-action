<div class="post-options align-center">

	<nav class="post-navigation button-wrap">
		<?php 
			$next_post = get_next_post();
			$prev_post = get_previous_post();

			if ( is_a( $next_post , 'WP_Post' ) )
				echo '<a class="prev-post" href="'. get_permalink( $next_post->ID ) .'">'. __('Previous', 'dtch') .'</a>';
			
			if ( is_a( $prev_post , 'WP_Post' ) )
			    echo '<a class="next-post" href="'. get_permalink( $prev_post->ID ) .'">'. __('Next', 'dtch') .'</a>';
		?>
	</nav>

	<?= do_shortcode('[social-media-share-buttons]'); ?>

</div>