<?php

$post_type = get_post_type();

if (isset($args["hero"])) {
	$hero = $args["hero"];
} else {
	$hero = get_field("page-hero")["hero"];
}

$image = $hero["image"];

if ($post_type === "post") {
	if (!$image) {
		$image = get_post_thumbnail_id();
	}
}

?>
<section class="hero spacing-row">
	<?php if (!is_front_page()): ?>
		<?php get_template_part("template-parts/global/breadcrumbs"); ?>
	<?php endif; ?>

	<div class="wrap">
		<div class="hero-content">
			<?php if ($hero["title"]): ?>
				<h1 class="title <?= strlen($hero["title"]) > 55 ? "small-text" : "" ?>"><?= $hero["title"] ?></h1>
			<?php endif; ?>

			<?php if ($hero["subtitle"]): ?>
				<p class="subtitle"><?= $hero["subtitle"] ?></p>
			<?php endif; ?>

			<?php if ($hero["text"]): ?>
				<p><?= $hero["text"] ?></p>
			<?php endif; ?>

			<?php if ($hero["cta"]): ?>
				<div class="cta-container">
					<?php $cta_count = 0; ?>
					<?php foreach ($hero["cta"] as $cta): ?>
						<a href="<?= $cta["link"]["url"] ?>" target="<?= $cta["link"]["target"] ?>" class="button <?= $cta_count > 0 ? "black" : "" ?>"><?= $cta["link"]["title"] ?></a>
						<?php $cta_count++; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ($post_type === "post" && is_single()): ?>
				<div class="post-meta">
					<div class="author">
						<?= render_svg_icon("", "user"); ?>
						<p><?= get_the_author(); ?></p>
					</div>
					<div>
						<?= render_svg_icon("", "calendar"); ?>
						<p><?= get_the_date(); ?></p>
					</div>
				</div>
			<?php endif; ?>

			<?php if (!is_404() && !is_search() && !is_single()): ?>
				<?= render_svg_icon("scroll-icon", "scroll"); ?>
			<?php endif; ?>

			<?php if ($post_type === "post" && is_single()): ?>
				<div></div>
				<?php get_template_part("template-parts/blog/table-of-contents"); ?>
			<?php endif; ?>

		</div>
		<?php if ($hero["show_trustmark"]): ?>
			<?php get_template_part("template-parts/global/reviews-trustmark"); ?>
		<?php endif; ?>
	</div>
	<div class="wrap large">
		<div></div>
		<figure class="hero-image">
			<?= wp_get_attachment_image($image, "large"); ?>
		</figure>
	</div>
</section>
