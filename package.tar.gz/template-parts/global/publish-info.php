<div class="publish-info smaller">

	<p class="date"><?= '<time datetime="'.get_the_date('Y-m-d h:i').'">'. get_the_date() .'</time>' ?></p>

	<p class="cats"><?php the_category( ', ' ); ?></p>
	
</div>