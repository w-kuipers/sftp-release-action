<?php
$footer_fields = get_field("footer", "option");
$company_info = get_field("global_info", "option")["company_info"];
$name = $company_info["name"];
?>

<div class="footer-copyright">
	<div class="wrap">
		<p class="footer-copyright__copy">
			&copy; 2011 - <?= date("Y"); ?> <?= $name; ?>. <?php _e("All rights reserved.", "dtch"); ?>
		</p>

		<?php if (isset($footer_fields["copyright-menu"])): ?>
			<ul class="footer-copyright__menu">
				<?php foreach ($footer_fields["copyright-menu"] as $item): ?>
					<li><a><?= $item["link"]["title"] ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<p class="footer-copyright__creator">
			<?= __("Realization:"); ?>
			<a href="https://dtchdigitals.com/nl/" title="Dtch. Digitals" target="_blank">Dtch. Digitals</a>
		</p>
	</div>
</div>
