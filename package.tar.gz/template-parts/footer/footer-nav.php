<?php
$company_info = get_field("global_info", "option")["company_info"];
$links = get_field("links", "option");
$footer = get_field("footer", "option");

$become_a_reseller = $links["become_a_reseller"];
$name = $company_info["name"];
$phone = $company_info["phone"];
$email = $company_info["email"];
$address = $company_info["address"];
$postal_code = $company_info["postal_code"];
$city = $company_info["city"];
$country = $company_info["country"];
$form = $footer["form"];
$trustmarks = $footer["trustmarks"];

// Footer menus sometimes stack,
$menu_count = 0;
if ($footer["menu"]) {
    $menu_count = count($footer["menu"]);
}
?>

<div class="footer-nav">
	<div class="wrap has-<?php echo $menu_count ?>">
		<div class="footer-nav__item">
			<p class="footer-nav__title"><?php echo __("Contact information", "dtch"); ?></p>

			<div class="footer-nav__contact-info">
				<p class="footer-nav__contact-info__name"><?php echo $name ?></p>

				<?php if ($phone) : ?>
					<a href="tel:<?php echo $phone ?>" class="footer-nav__contact-info-item">
						<?php echo render_svg_icon("", "phone"); ?>
						<?php echo $phone ?>
					</a>
				<?php endif; ?>

				<?php if ($email) : ?>
					<a href="tel:<?php echo $email ?>" class="footer-nav__contact-info-item">
						<?php echo render_svg_icon("", "email"); ?>
						<?php echo $email ?>
					</a>
				<?php endif; ?>

				<?php if ($address || ($postal_code && $city) || $country) : ?>
					<div class="footer-nav__contact-info-item location">
						<?php echo render_svg_icon("", "location"); ?>
						<div class="footer-nav__contact-info-item__location">
							<?php if ($address) : ?>
								<p><?php echo $address; ?></p>
							<?php endif; ?>
							<?php if ($postal_code && $city) : ?>
								<p><?php echo $postal_code; ?> <?php echo $city ?></p>
							<?php endif; ?>
							<?php if ($country) : ?>
								<p><?php echo $country ?></p>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ($become_a_reseller) : ?>
					<a href="<?php echo $become_a_reseller ?>" class="footer-nav__contact-info-item reseller">
						<?php echo render_svg_icon("", "handshake"); ?>
						<?php echo __("Become a reseller", "dtch"); ?>
					</a>
				<?php endif; ?>

			</div>
		</div>

		<div class="footer-nav__group">
			<?php for ($m = 0; $m < 2; $m++): ?>
				<?php if ($footer["menu"][$m]) : ?>
					<div class="footer-nav__item">
						<div class="footer-nav__title">
							<p><?php echo $footer["menu"][$m]["title"] ?></p>
							<?php echo render_svg_icon("", "chevron-down"); ?>
						</div>

						<div class="footer-nav__menu">
							<?php foreach ($footer["menu"][$m]["links"] as $link): ?>
								<a href="<?php echo $link["link"]["url"] ?>" target="<?php echo $link["link"]["target"] ?>"><?php echo $link["link"]["title"] ?></a>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			<?php endfor; ?>
		</div>

		<?php for ($m = 2; $m < $menu_count - 1; $m++): ?>
			<?php if ($footer["menu"][$m]) : ?>
				<div class="footer-nav__item">
					<div class="footer-nav__title">
						<p><?php echo $footer["menu"][$m]["title"] ?></p>
						<?php echo render_svg_icon("", "chevron-down"); ?>
					</div>

					<div class="footer-nav__menu">
						<?php foreach ($footer["menu"][$m]["links"] as $link): ?>
							<a href="<?php echo $link["link"]["url"] ?>" target="<?php echo $link["link"]["target"] ?>"><?php echo $link["link"]["title"] ?></a>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
		<?php endfor; ?>

		<div class="footer-nav__group">
			<div class="footer-nav__item">
				<div class="footer-nav__title">
					<p><?php echo $footer["menu"][$menu_count - 1]["title"] ?></p>
					<?php echo render_svg_icon("", "chevron-down"); ?>
				</div>

				<div class="footer-nav__menu">
					<?php foreach ($footer["menu"][$menu_count - 1]["links"] as $link): ?>
						<a href="<?php echo $link["link"]["url"] ?>" target="<?php echo $link["link"]["target"] ?>"><?php echo $link["link"]["title"] ?></a>
					<?php endforeach; ?>
				</div>
			</div>

			<div id="newsletter" class="footer-nav__item form">
				<?php if ($form) : ?>
					<?php if ($footer["title"]) : ?>
						<p class="footer-nav__title"><?php echo $footer["title"] ?></p>
					<?php endif; ?>
					<?php echo do_shortcode("[gravityform id='$form' title='false' description='false']"); ?>
				<?php endif; ?>
			</div>
		</div>

		<div class="footer-nav__group">
			<?php if ($links["contact"]) : ?>
				<div class="footer-nav__item">
					<p class="footer-nav__title"><?php echo __("Contact us"); ?></p>
					<a class="button"><?php echo __("Get expert advice", "dtch"); ?></a>
				</div>
			<?php endif; ?>

			<div class="footer-nav__item social-media">
				<p class="footer-nav__title"><?php echo __("Follow us"); ?></p>
				<?php get_template_part("template-parts/global/social-media"); ?>
			</div>
			<div class="footer-nav__item trustmarks">
				<?php foreach ($trustmarks as $trustmark): ?>
					<figure><?php echo wp_get_attachment_image($trustmark["logo"], "small", false, array("class" => "lazy")); ?></figure>
				<?php endforeach; ?>
			</div>
		</div>

	</div>
</div>
