<?php 
	if ( class_exists('ACF') ) :

		if ( get_field('logo_alternative', 'option') ) : 
?>
			<a class="site-logo" href="<?= site_url(); ?>" title="<?php esc_attr_e( get_bloginfo('name') ); ?>">

				<?php
					$img_id = get_field('logo_alternative', 'option');
					if ( isset( $img_id ) && ( ! empty( $img_id ) ) )
						echo wp_get_attachment_image( $img_id, 'small', false, array( 'class' => '' ) );
				?>

			</a>
<?php 
		endif; 

	endif; 	
?>