<form role="search" method="get" class="search-form" action="<?= esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e('Search', 'dtch'); ?>">
	<p class="form-row">
		<label><?php _e('Search:', 'dtch'); ?></label>
		<input type="search" class="search-form__input" aria-label="<?php esc_attr_e('Search through site content', 'dtch'); ?>" placeholder="<?= esc_attr_e( 'Search &hellip;', 'dtch' ); ?>" value="<?= get_search_query(); ?>" name="s" />
	</p>
	<button type="submit" class="search-form__button" aria-label="<?php esc_attr_e('Search', 'dtch'); ?>"><?= render_svg_icon('search-form__icon', 'search'); ?></button>
</form>
