<?php
$global_info = get_field("global_info", "option");
$logo = $global_info["logo"];
?>

<a class="site-logo" href="<?php echo site_url(); ?>" title="<?php esc_attr_e(get_bloginfo('name')); ?>">
    <?php if ($logo) : ?>
        <?php echo wp_get_attachment_image($logo, "small", false, array("class" => "")); ?>
    <?php endif; ?>
</a>
