<?php 
  global $product;
  $attachment_ids 	= $product->get_gallery_image_ids();  
  $post_thumb_id 	= get_post_thumbnail_id( get_the_ID() );
  if( count( $attachment_ids) > 0 ) { 
?>

<div id="thumbnail-slider">
  <ul class="slides">
    <?php 
  		echo '	<li>'. wp_get_attachment_image( $post_thumb_id, 'thumbnail', false, array() ) .'</li>'; 

	  	foreach( $attachment_ids as $img_id ) {
	  		echo '	<li>'. wp_get_attachment_image( $img_id, 'thumbnail', false, array() ) .'</li>'; 
	  	}
  	?>
  </ul>
</div>

<script>
	var $j = jQuery.noConflict();

	$j( document ).ready( function($) {

		$j('#thumbnail-slider').flexslider({
			animation: "slide",
			controlNav: false,
			directionNav: false,
			animationLoop: false,
			slideshow: false,
			itemWidth: 100,
			itemMargin: 0,
			asNavFor: '.woocommerce-product-gallery',
			prevText: '<?= render_svg_icon( '', 'chevron-left'); ?>',
			nextText: '<?= render_svg_icon( '', 'chevron-right'); ?>'
		});
	});

</script>

<?php } ?>


