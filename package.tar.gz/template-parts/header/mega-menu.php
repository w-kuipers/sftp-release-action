<?php
$menu_id = $args["menu_id"];
$megamenu = get_post($menu_id);
$links = get_field("links", "option");
?>

<div class="mega-menu">
	<div class="wrap">
		<div class="mega-menu-items">
			<?php while (have_rows("menu_item", $megamenu)): the_row() ?>
				<div class="mega-menu-item">
					<p class="title"><?= get_sub_field("title")["title"]; ?></p>
					<figure>
						<?= wp_get_attachment_image(get_sub_field("image"), "small", false, array("class" => "lazy")); ?>
					</figure>

					<ul class="links">
						<?php foreach (get_sub_field("subitems") as $subitem): ?>
							<li><a href="<?= $subitem["link"]["url"] ?>" target="<?= $subitem["link"]["target"] ?>"><?= $subitem["link"]["title"] ?> <?= render_svg_icon("", "chevron-right"); ?></a></li>
						<?php endforeach; ?>
					</ul>

					<?php $cta = get_sub_field("cta"); ?>
					<?php if ($cta): ?>
						<a class="button outline" href="<?= $cta["url"] ?>" target="<?= $cta["target"] ?>"><?= $cta["title"]; ?></a>
					<?php endif; ?>
				</div>
			<?php endwhile; ?>
		</div>

		<div class="mega-menu-footer">
			<?php if ($links): ?>
				<p><?= __("Not sure what you need?", "dtch"); ?></p>
				<a class="button mobile" href="<?php echo $links["contact"] ?>?f=<?php echo $links["expert_advise_form"] ?>"><?php echo __("Get expert advise", "Dtch"); ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>
