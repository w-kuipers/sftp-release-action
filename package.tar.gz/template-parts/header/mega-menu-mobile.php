<?php
$menu_id = $args["menu_id"];
$megamenu = get_post($menu_id);
$links = get_field("links", "option");
?>

<div class="mobile-mega-menu">
	<div class="wrap">
		<div class="mobile-mega-menu-items">
			<?php while (have_rows("menu_item", $megamenu)): the_row() ?>
				<div class="mobile-mega-menu-item">
					<?php $title = get_sub_field("title"); ?>

					<div class="title">
						<a href="<?= $title["url"] ?>"><?= $title["title"]; ?></a>
						<div class="submenu-trigger" data-submenu-index="<?= get_row_index(); ?>"><?= render_svg_icon("", "chevron-right"); ?></div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
	<?php while (have_rows("menu_item", $megamenu)): the_row() ?>
		<div id="megamenu-submenu-<?= get_row_index(); ?>" class="mobile-mega-menu-submenu">
			<div class="megamenu-submenu-back">
				<?= render_svg_icon("", "arrow-left"); ?>
				<p><?= get_sub_field("title")["title"]; ?></p>
			</div>
			<ul class="links">
				<?php foreach (get_sub_field("subitems") as $subitem): ?>
					<li><a href="<?= $subitem["link"]["url"] ?>" target="<?= $subitem["link"]["target"] ?>"><?= $subitem["link"]["title"] ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endwhile; ?>
</div>
