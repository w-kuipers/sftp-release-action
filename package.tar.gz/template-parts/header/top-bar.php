<?php
$links = get_field("links", "option");
$company_info = get_field("global_info", "option")["company_info"];
?>

<div class="top-bar">
	<ul>
		<?php if ($company_info["email"]) : ?>
			<li>
				<a href="mailto:<?php echo $company_info["email"] ?>">
					<?php echo render_svg_icon("", "email"); ?>
					<?php echo $company_info["email"] ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if ($links["become_a_reseller"]) : ?>
			<li>
				<a href="<?php echo $links["become_a_reseller"] ?>">
					<?php echo render_svg_icon("", "handshake"); ?>
					<?php echo __("Become a reseller", "dtch") ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if (has_nav_menu("language-navigation")) : ?>
			<li>
				<?php get_template_part("template-parts/global/language-switch"); ?>
			</li>
		<?php endif; ?>
	</ul>
</div>
