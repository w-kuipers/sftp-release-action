<?php
$links = get_field("links", "option");

class MenuWalker extends Walker_Nav_Menu
{
	public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0)
	{
		$megamenu = get_field("mega_menu", $item);

		if ($megamenu) {
			array_push($item->classes, "menu-item-has-children");
		}

		$output .= "<div class='menu-indicator'></div>";
		parent::start_el($output, $item, $depth, $args, $id);
		if ($megamenu) {
			ob_start();
			get_template_part("template-parts/header/mega-menu", null, ["menu_id" => $megamenu]);
			$template_part_content = ob_get_clean();
			$output .= $template_part_content;
		}
	}
}

$menu = array(
	"theme_location" => "main-navigation",
	"container_class" => "nav-bar__menu-wrap",
	"walker" => new MenuWalker()
);
?>

<div class="nav-bar">
	<div class="wrap large">

		<?php get_template_part("template-parts/shortcodes/site-logo"); ?>

		<div class="nav-bar-content">
			<div class="nav-bar-content-top">
				<?php get_template_part("template-parts/header/top-bar"); ?>
			</div>

			<div class="nav-bar-content-bottom">
				<div class="nav-bar-content-bottom-left">
					<?php if (has_nav_menu("main-navigation")) : ?>
						<?php wp_nav_menu($menu); ?>
					<?php endif; ?>
				</div>

				<div class="nav-bar-content-bottom-right">
					<form role="search" method="get" id="header-search-form" class="search-form" action="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Search', 'dtch'); ?>">
						<input type="search" class="search-form__input" id="header-search-input" aria-label="<?php esc_attr_e('Search through site content', 'dtch'); ?>" placeholder="<?php echo esc_attr_e('Search &hellip;', 'dtch'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
						<button class="button light icon" id="header-search-button" aria-label="<?php esc_attr_e("Search", "dtch"); ?>"><?php echo render_svg_icon("search-form__icon", "search") ?></button>
					</form>

					<?php if ($links["contact"] && $links["expert_advise_form"]) : ?>
						<a title="<?php echo __("Get expert advise", "Dtch"); ?>" class="button desktop" href="<?php echo $links["contact"] ?>?f=<?php echo $links["expert_advise_form"] ?>"><?php echo __("Get expert advise", "Dtch"); ?></a>
					<?php endif; ?>

					<?php if ($links["contact"]) : ?>
						<a title="<?php echo __("Contact us", "Dtch"); ?>" class="button desktop" href="<?php echo $links["contact"] ?>"><?php echo __("Contact us", "Dtch"); ?></a>
					<?php endif; ?>

					<?php if ($links["contact"] && $links["expert_advise_form"]) : ?>
						<a title="<?php echo __("Get advise", "Dtch"); ?>" class="button mobile" href="<?php echo $links["contact"] ?>?f=<?php echo $links["expert_advise_form"] ?>"><?php echo __("Get advise", "Dtch"); ?></a>
					<?php elseif ($links["contact"]) : ?>
						<a title="<?php echo __("Contact us", "Dtch"); ?>" class="button mobile" href="<?php echo $links["contact"] ?>"><?php echo __("Contact us", "Dtch"); ?></a>
					<?php endif; ?>

					<?php get_template_part("template-parts/mobile/mobile-nav-toggle"); ?>

				</div>
			</div>
		</div>

	</div>
</div>
