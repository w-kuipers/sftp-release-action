<?php
$links = get_field("links", "option");

class MobileMenuWalker extends Walker_Nav_Menu
{
	function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0)
	{
		$megamenu = get_field("mega_menu", $item);

		if ($megamenu) {
			array_push($item->classes, "menu-item-has-children");
		}

		if (in_array('menu-item-has-children', $item->classes) || $megamenu) {
			$title          = $item->title;
			$item->title    = $title . '<span onclick="toggleMobNavItem(this); return false;" class="menu-item__toggle">' . render_svg_icon('', 'chevron-down') . '</span>';
			$item->attr_title = $title;
		}

		parent::start_el($output, $item, $depth, $args, $id);
		if ($megamenu) {
			ob_start();
			get_template_part("template-parts/header/mega-menu-mobile", null, ["menu_id" => $megamenu]);
			$template_part_content = ob_get_clean();
			$output .= $template_part_content;
		}
	}
}

$menu = array(
	"theme_location" => "main-navigation",
	"container_class" => "mobile-navigation__menu-wrap",
	"walker" => new MobileMenuWalker()
);
?>

<?php if (has_nav_menu('main-navigation')) : ?>
	<nav class="mobile-navigation">
		<div class="mobile-navigation-content">
			<div class="wrap">
				<?php get_template_part('template-parts/global/search-form'); ?>
				<?php wp_nav_menu($menu); ?>
				<?= do_shortcode('[social-media-icons]'); ?>


				<div class="mobile-navigation-footer">
					<?php if ($links): ?>
						<p><?= __("Not sure what you need?", "dtch"); ?></p>
						<a class="button mobile" href="<?php echo $links["contact"] ?>?f=<?php echo $links["expert_advise_form"] ?>"><?php echo __("Get expert advise", "Dtch"); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</nav>
<?php endif; ?>
