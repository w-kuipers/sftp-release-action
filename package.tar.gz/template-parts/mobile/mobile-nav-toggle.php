<div class="mobile-nav-toggle">
    <button class="mobile-nav-toggle__button" onclick="toggleMobNav(this);" title="<?php esc_attr_e('Show navigation', 'dtch'); ?>" aria-label="<?php esc_attr_e('Show navigation', 'dtch'); ?>">
        <span class="strokes">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </button>
</div>
