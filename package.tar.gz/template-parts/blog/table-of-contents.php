<?php global $table_of_contents; ?>

<select id="table-of-contents" class="table-of-contents">
	<option disabled selected><?= __("Table of contents", "dtch"); ?></option>
	<?php foreach ($table_of_contents as $item): ?>
		<option value="<?= $item["id"] ?>"><?= $item["title"] ?></option>
	<?php endforeach; ?>
</select>
