const sass = require('sass');
const fs = require('fs');
const path = require('path');

const outputDir = path.join(__dirname, 'assets/css');
const outputFile = path.join(outputDir, 'dd_style.css');
const outputMapFile = path.join(outputDir, 'dd_style.css.map');

if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
}

try {
    
    // Compile and minify SASS with source map generation
    const sassResult = sass.compile(path.join(__dirname, '_src/sass/style.scss'), {
        style: 'compressed', // Minify the output
        sourceMap: true, // Generate source map
    });

    // Write the minified CSS including the source map reference automatically added by Dart Sass
    fs.writeFileSync(outputFile, sassResult.css);

    // Ensure the source map reference is added to the CSS file
    fs.appendFileSync(outputFile, `/*# sourceMappingURL=${path.basename(outputMapFile)} */`);

    // Write the source map if available
    if (sassResult.sourceMap) {
        fs.writeFileSync(outputMapFile, JSON.stringify(sassResult.sourceMap));
    }

    console.log('SASS compiled and CSS minified successfully.');

} catch (error) {

    console.error('Error during SASS compilation/minification:', error);

}
