const concat = require('concat');
const uglifyJS = require('uglify-js');
const fs = require('fs');
const path = require('path');

const jsDirectory = path.join(__dirname, '_src/js');
const outputDir = path.join(__dirname, 'assets/js'); // Updated output directory
const outputFile = path.join(outputDir, 'main.js'); // Updated output file path
const outputMapFile = path.join(outputDir, 'main.js.map'); // Updated source map file path

// Ensure the output directory exists
if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
}

// Function to recursively find all .js files
function findAllJsFiles(dir, fileList = []) {
    const files = fs.readdirSync(dir);

    files.forEach(file => {
        const filePath = path.join(dir, file);
        const fileStat = fs.statSync(filePath);

        if (fileStat.isDirectory()) {
            findAllJsFiles(filePath, fileList); // Recurse into subdirectories
        } else if (filePath.endsWith('.js')) {
            fileList.push(filePath);
        }
    });

    return fileList;
}

// Automatically read all .js files from the _src/js folder
const files = findAllJsFiles(jsDirectory);

// Concatenate JS files
concat(files).then(result => {
  // Minify concatenated result
  const minified = uglifyJS.minify(result, {
    sourceMap: {
      filename: 'main.js',
      url: 'main.js.map'
    }
  });

  if (minified.error) {
    console.error('Error minifying JS:', minified.error);
    return;
  }

  // Write the minified JS
  fs.writeFileSync(outputFile, minified.code);
  // Optionally, write the source map if needed
  if (minified.map) {
    fs.writeFileSync(outputMapFile, minified.map);
  }

  console.log('JS concatenated and minified successfully.');
}).catch(error => {
  console.error('Error during JS concatenation/minification:', error);
});
