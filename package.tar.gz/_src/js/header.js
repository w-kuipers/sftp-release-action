// Handle search bar show on click
const headerSearchForm = document.getElementById("header-search-form");
const headerSearchInput = document.getElementById("header-search-input");
const headerSearchButton = document.getElementById("header-search-button");

headerSearchButton.addEventListener("click", function() { });
document.addEventListener("click", function(e) {
	if (e.target === headerSearchButton || e.target === headerSearchInput) {
		// If the search form is not visible, show it
		if (!headerSearchForm.classList.contains("open")) {
			e.preventDefault();
			headerSearchInput.style.maxWidth = "40rem";
			headerSearchInput.style.width = "40rem";
			headerSearchForm.classList.add("open");

			setTimeout(() => {
				headerSearchInput.focus();
			}, 100);
		}
		return;
	}

	if (headerSearchForm.classList.contains("open")) {
		headerSearchForm.classList.remove("open");
		headerSearchInput.style.maxWidth = 0;
	}
});

// Handle mega menu show on hover
const menuItems = document.getElementsByClassName("menu-item");
const backdrop = document.getElementsByClassName("backdrop")[0];
for (let m = 0; m < menuItems.length; m++) {
	// Check if menu item has megamenu
	const megaMenu = menuItems[m].getElementsByClassName("mega-menu");
	const indicator = menuItems[m].getElementsByClassName("menu-indicator")[0];
	if (megaMenu.length > 0) {
		menuItems[m].addEventListener("mouseover", function() {
			megaMenu[0].classList.add("open");
			backdrop?.classList.add("active");
			indicator?.classList.add("active");
		});

		menuItems[m].addEventListener("mouseleave", function() {
			megaMenu[0].classList.remove("open");
			backdrop?.classList.remove("active");
			indicator?.classList.remove("active");
		});
	}
}
