const footerMenuCollapseTriggers = document.getElementsByClassName("footer-nav__title");

// Set initial open
document.addEventListener("DOMContentLoaded", function() {
	const firstTrigger = footerMenuCollapseTriggers[1];
	const firstParent = firstTrigger.parentElement;
	const firstMenu = firstTrigger.nextElementSibling;
	firstParent.classList.add("open");
	firstMenu.style.maxHeight = firstMenu.scrollHeight + "px";
});

for (let t = 0; t < footerMenuCollapseTriggers.length; t++) {
	footerMenuCollapseTriggers[t].addEventListener("click", function() {
		const parent = this.parentElement;
		const menu = this.nextElementSibling;

		// Close if already open
		if (parent.classList.contains("open")) {
			parent.classList.remove("open");
			menu.style.maxHeight = 0;
			return;
		}

		parent.classList.add("open");
		menu.style.maxHeight = menu.scrollHeight + "px";
	});
}
