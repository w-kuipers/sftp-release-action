const formSelect = document.getElementById("contact-page-form-select");
const formsContainer = document.getElementById("contact-page-form-container");
const forms = document.querySelectorAll(".form-container .form");

const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const defaultForm = urlParams.get("f");

if (formSelect !== null) {
	if (defaultForm !== null) {
		formsContainer.scrollIntoView({
			behavior: "smooth",
			block: "center",
		});

		// Hide all forms
		for (let f = 0; f < forms.length; f++) {
			forms[f].classList.remove("active");
		}

		const selectedForm = document.querySelector(".form-container .form[data-form-id='" + defaultForm + "']");
		selectedForm.classList.add("active");

		formSelect.value = defaultForm;
	}

	formSelect.addEventListener("change", function(e) {
		// Hide all forms
		for (let f = 0; f < forms.length; f++) {
			forms[f].classList.remove("active");
		}

		// Show selected form
		const selectedForm = document.querySelector(".form-container .form[data-form-id='" + e.target.value + "']");
		selectedForm.classList.add("active");
	});
}
