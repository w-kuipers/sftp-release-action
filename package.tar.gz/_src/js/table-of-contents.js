const tableOfContents = document.getElementById("table-of-contents");

tableOfContents.addEventListener("change", (e) => {
	console.log("test");
	const element = document.getElementById(e.target.value);

	element.scrollIntoView({
		behavior: "smooth",
		block: "center",
	});
});
