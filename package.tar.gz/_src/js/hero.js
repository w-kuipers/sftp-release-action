const scrollIcon = document.getElementById("mouse-down");
const flexContainer = document.getElementsByClassName("flex-content-container")[0];
const secondRow = flexContainer?.getElementsByTagName("section")[1];

scrollIcon?.addEventListener("click", () => {
	secondRow?.scrollIntoView({
		behavior: "smooth",
	});
});
