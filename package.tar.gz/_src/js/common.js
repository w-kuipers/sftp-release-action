var $j = jQuery.noConflict();

$j(document).ready(function($) {
	// Enable lazyload script
	$j(".lazy").lazyload();

	// Enable fancybox
	Fancybox.bind("[data-fancybox]");

	// If url contains hash, scroll to element
	if (window.location.hash !== "") {
		var hash = window.location.hash;

		if (hash.length > 1 && $j(hash).length > 0) scrollToElement(hash);
	}

	// Add class to element if is in viewport
	$j(".animated-view").each(function() {
		if (isInViewport($j(this))) {
			$j(this).addClass("in-view");
		} else {
			$j(this).removeClass("in-view");
		}
	});

	// Animated scroll to element (anchor linking)
	$j(".anchor-link, .anchor-link-wrap a").click(function() {
		var target = $j(this).attr("href");
		scrollToElement(target);
		return false;
	});

	// Responsive video wrapper activate
	$j(".responsive-video-wrapper .play-button").on("click", function(button) {
		button.preventDefault();
		var iframe = $j(this).parent().find(".lazy-iframe");

		iframe.attr("src", iframe.data("src"));
		$j(this).parent().addClass("clicked");
		$j(this).parent().find(".fa-play").fadeOut(200);
		$j(this).fadeOut(2000);

		return false;
	});

	//Trigger scroll window
	$j(window).scroll(function() {
		windowScroll();
	});

	windowScroll();
});

// Selectbox to URL
function selectToUrl(elem) {
	url = $j(elem).val();
	if (url !== "") {
		window.location.href = url;
	}
}

// Toggle mobile navigation
function toggleMobNav() {
	$j("body").toggleClass("mob-nav-active");
}

// Functions to execute by scrollv
function windowScroll() {
	var scrollPosition = $j(window).scrollTop();

	// Set scrolled class on body after scrolled
	if (scrollPosition > 0) {
		$j("body").addClass("scrolled");
	} else {
		$j("body").removeClass("scrolled");
	}

	// Add class to element if is in viewport
	$j(".animated-view").each(function() {
		if (isInViewport($j(this))) {
			$j(this).addClass("in-view");
		} else {
			$j(this).removeClass("in-view");
		}
	});
}

// Scroll to function
function scrollToElement(target) {
	const element = document.querySelector(target);

	element.scrollIntoView({
		behavior: "smooth",
		block: "center",
	});

	return false;
}

// Toggle mobile submenu
function toggleMobNavItem(button) {
	var button = $j(button);
	var subMenu = button.parent().next();

	button.toggleClass("active");
	subMenu.slideToggle("fast");
}

function toggleAnswer(el) {
	$j(el).toggleClass("active").parent().next().slideToggle("fast");
}

// Check if element is in viewport
function isInViewport(elem) {
	var elementTop = $j(elem).offset().top;
	var elementBottom = elementTop + $j(elem).outerHeight();
	var viewportTop = $j(window).scrollTop();
	var viewportBottom = viewportTop + $j(window).height();

	return elementBottom > viewportTop && elementTop < viewportBottom;
}
