const accordionTriggers = document.querySelectorAll(".accordion-trigger");
const accordionContents = document.querySelectorAll(".accordion-content");

// Loop over triggers and add click event listeners to every iteration
for (let f = 0; f < accordionTriggers.length; f++) {
	// Set initial active trigger open
	if (accordionTriggers[f].parentElement.classList.contains("active"))
		accordionTriggers[f].nextElementSibling.style.maxHeight =
			accordionTriggers[f].nextElementSibling.scrollHeight + "px";

	accordionTriggers[f].addEventListener("click", function() {
		// Close all others before opening a new one
		for (let i = 0; i < accordionContents.length; i++) {
			accordionContents[i].style.maxHeight = null;
			accordionContents[i].parentElement.classList.remove("active");
		}

		// Hide all images
		const images = document.getElementsByClassName("accordion-block-image");
		for (let i = 0; i < images.length; i++) {
			images[i].style.opacity = 0;
		}

		// Open/close item by setting height
		const content = this.nextElementSibling;
		const parent = this.parentElement;
		if (parent.classList.contains("active")) {
			content.style.maxHeight = null;
			parent.classList.remove("active");
		} else {
			content.style.maxHeight = content.scrollHeight + "px";
			parent.classList.add("active");

			const imageId = parent.dataset.accordionCount;
			const image = document.querySelector(`.accordion-block-image[data-image-count="${imageId}"]`);
			image.style.opacity = 1;
		}
	});
}
