const submenuTriggers = document.querySelectorAll(".mobile-mega-menu-item .submenu-trigger");
const submenuBackButtons = document.getElementsByClassName("megamenu-submenu-back");

for (let m = 0; m < submenuTriggers.length; m++) {
	submenuTriggers[m].addEventListener("click", function() {
		const submenuIndex = submenuTriggers[m].dataset.submenuIndex;
		const submenu = document.getElementById("megamenu-submenu-" + submenuIndex);

		submenu.classList.add("active");
	});
}

for (let b = 0; b < submenuBackButtons.length; b++) {
	submenuBackButtons[b].addEventListener("click", function() {
		submenuBackButtons[b].parentElement.classList.remove("active");
	});
}
