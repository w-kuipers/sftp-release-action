const categoriesSlider = new Swiper(".categories-slider", {
	slidesPerView: 1.2,
	spaceBetween: 10,

	breakpoints: {
		1023: {
			slidesPerView: 2,
		},
		1440: {
			slidesPerView: 3,
		},
	},
});

const flexSlider = new Swiper(".flex-slider", {
	slidesPerView: 1.3,
	spaceBetween: 10,
	initialSlide: 0,
	breakpoints: {
		1023: {
			slidesPerView: 1.1,
			spaceBetween: 40,
			initialSlide: 1,
		},
	},
});

const reviewSlider = new Swiper(".review-slider", {
	slidesPerView: 1.2,
	spaceBetween: 10,
	navigation: {
		nextEl: ".review-slider-next",
		prevEl: ".review-slider-prev",
	},
	breakpoints: {
		1023: {
			slidesPerView: 2,
		},
		1350: {
			slidesPerView: 3,
			spaceBetween: 20,
		},
	},
});

const featuredBlogsSlider = new Swiper(".featured-blogs-slider", {
	slidesPerView: 1.2,
	spaceBetween: 10,

	breakpoints: {
		1023: {
			slidesPerView: 2,
		},
		1440: {
			slidesPerView: 3,
		},
	},
});

const featuredProductsSlider = new Swiper(".featured-products-slider", {
	slidesPerView: 1.2,
	spaceBetween: 10,

	breakpoints: {
		1023: {
			slidesPerView: 2,
		},
		1440: {
			slidesPerView: 3,
		},
	},
});

const cardsSlider = new Swiper(".cards-slider", {
	slidesPerView: 1.2,
	spaceBetween: 10,

	breakpoints: {
		1023: {
			slidesPerView: 2,
		},
		1440: {
			slidesPerView: 3,
		},
	},
});
