const bottomPageShape = document.getElementById("bottom-page-shape");
const backgroundShapes = document.getElementById("background-shapes-parent");
const pageContainer = document.getElementById("main");
const footer = document.getElementById("footer");

bottomPageShape.style.top = pageContainer.scrollHeight - 2200 + "px";
backgroundShapes.style.height = pageContainer.scrollHeight + footer.scrollHeight / 2 + "px";

const resizeObserver = new ResizeObserver((entries) => {
	for (let entry of entries) {
		bottomPageShape.style.top = entry.contentRect.height - 2200 + "px";
		backgroundShapes.style.height = entry.contentRect.height + footer.scrollHeight / 2 + "px";

		if (entry.contentRect.height < 8800) {
			bottomPageShape.style.display = "none";
		} else {
			bottomPageShape.style.display = "block";
		}
	}
});

resizeObserver.observe(pageContainer);
