const chokidar = require('chokidar');
const debounce = require('lodash.debounce');
const sass = require('sass');
const CleanCSS = require('clean-css');
const fs = require('fs');
const path = require('path');

const sassDirectory = path.join(__dirname, '_src/sass');
const outputDir = path.join(__dirname, 'assets/css');
const outputFile = path.join(outputDir, 'dd_style.css'); 
const outputMapFile = path.join(outputDir, 'dd_style.css.map');

// Compile and minify SASS with debouncing to prevent excessive runs
const debouncedCompileAndMinifySASS = debounce(compileAndMinifySASS, 300);

function compileAndMinifySASS() {

    try {

        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        // Adjusted to use Dart Sass for both minification and source map generation
        const sassResult = sass.compile(path.join(sassDirectory, 'style.scss'), {
            outputStyle: 'compressed', 
            sourceMap: true, 
        });

        // Write the minified CSS, Dart Sass includes the source map reference automatically
        fs.writeFileSync(outputFile, sassResult.css);

        // Ensure the source map reference is added to the CSS file
        fs.appendFileSync(outputFile, `/*# sourceMappingURL=${path.basename(outputMapFile)} */`);

        // Write the source map if available
        if (sassResult.sourceMap) {
            fs.writeFileSync(outputMapFile, JSON.stringify(sassResult.sourceMap));
        }

        console.log('SASS compiled and CSS minified successfully.');

    } catch (error) {

        console.error('Error during SASS compilation/minification:', error);

    }

}

const watcher = chokidar.watch(sassDirectory, {
    ignored: path.join(__dirname, 'assets/**'),
    persistent: true,
});

watcher
    .on('add', debouncedCompileAndMinifySASS)
    .on('change', debouncedCompileAndMinifySASS)
    .on('unlink', debouncedCompileAndMinifySASS);

console.log('Watching for SCSS changes...');
