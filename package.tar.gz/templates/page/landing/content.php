<div class="flex-content-container">
	<?php get_template_part("template-parts/global/hero"); ?>
	<?php get_template_part("template-parts/flexible/index"); ?>
</div>
