<?php
$content = get_field("content");
$forms = get_field("forms");
?>

<div class="flex-content-container">
	<?php get_template_part("template-parts/global/hero"); ?>
	<?php get_template_part("template-parts/flexible/rows/image-cards", null, array("content" => $content["_image_cards"])); ?>

	<div class="wrap spacing-row">
		<div class="contact-forms">
			<div class="title-container">
				<h2><?= __("CHOOSE YOUR INQUIRY REASON FOR CONTACT HERE", "dtch") ?></h2>
				<p class="subtitle"><?= __("Let us help you<br>bring your ideas to life.", "dtch"); ?></p>
			</div>

			<select id="contact-page-form-select" placeholder="<?= __("Select an inquiry reason", "dtch") ?>">
				<?php foreach ($forms as $form): ?>
					<option value="<?= $form["form"] ?>"><?= $form["title"] ?></option>
				<?php endforeach; ?>
			</select>

			<div id="contact-page-form-container" class="form-container">
				<?php $c = 0; ?>
				<?php foreach ($forms as $form): ?>
					<div data-form-id="<?= $form["form"] ?>" class="form <?= $c === 0 ? "active" : null ?>">
						<?= do_shortcode("[gravityform id='" . $form["form"] . "' title='false' description='false']"); ?>
					</div>
					<?php $c++; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>
