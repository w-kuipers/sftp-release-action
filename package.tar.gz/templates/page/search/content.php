<?php
$bg_image = get_field("search-hero-background-image", "option");

$hero = array(
	"title" => __("Search results", "dtch"),
	"subtitle" => sprintf(__('You searched for "%s"', "dtch"), get_search_query()),
	"text" => null,
	"cta" => null,
	"show_trustmark" => false,
	"image" => $bg_image
);
?>

<section id="search-page">

	<?php
	global $wp_query;
	$args = array(
		'posts_per_page' => 50,
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key' 		=> '_yoast_wpseo_meta-robots-noindex',
				'compare' 	=> 'NOT EXISTS'
			)
		)
	);
	query_posts(
		array_merge(
			$args,
			$wp_query->query
		)
	);
	$products 	= array();
	$paginas 	= array();
	$articles 	= array();
	?>

	<?php if (have_posts()) : ?>
		<?php get_template_part("template-parts/global/hero", null, array("hero" => $hero)); ?>
		<?php while (have_posts()) : the_post(); ?>
			<?php

			switch ($post->post_type):

				case 'product':
					$products[] = $post;
					break;

				case 'page':
					$paginas[] = $post;
					break;

				case 'post':
					$articles[] = $post;
					break;

			endswitch;
			?>
		<?php endwhile; ?>

		<?php wp_reset_postdata(); ?>

		<?php
		$type = '';
		$typesArray = array(
			array(__('Products', 'dtch'), $products),
			array(__('Pages', 'dtch'), $paginas),
			array(__('Articles', 'dtch'), $articles),
		);
		?>

		<div class="wrap spacing-row">
			<div id="searchresults" class="clearfix">

				<?php

				foreach ($typesArray as $type) :

					if (count($type[1]) > 0) : ?>

						<div class="search-results-block">

							<h2><?php echo $type[0]; ?></h2>

							<?php if ($type[0] == __('Products', 'dtch')) : ?>

								<ul class="products">

									<?php
									foreach ($products as $p) :
										global $post;
										$post = $p;
										setup_postdata($post);
										wc_get_template_part('content', 'product');
										wp_reset_postdata();
									endforeach;
									?>

								</ul>


							<?php else : ?>

								<ol class="three-columns">

									<?php foreach ($type[1] as $item) : ?>

										<li>
											<a href="<?php echo get_permalink($item->ID) ?>" rel="bookmark" title="<?php echo $item->post_title; ?>">
												<?php echo $item->post_title; ?>
											</a>
										</li>

									<?php endforeach; ?>

								</ol>

							<?php endif; ?>

						</div>

				<?php endif;

				endforeach;

				?>

			</div>
		</div>

	<?php else : ?>
		<?php
		$hero["title"] = __("Unforunately", "dtch");
		$hero["subtitle"] = sprintf(__('No matches were found with your search term. Click <a href="%s" title="To the homepage">here</a> to go to the homepage.', "dtch"), get_site_url());
		$hero["text"] = sprintf(__('If you have any questions you can also <a href="%s" title="Contact"> contact us </a>.', "dtch"), get_site_url() . "/contact");
		?>
		<?php get_template_part("template-parts/global/hero", null, array("hero" => $hero)); ?>
	<?php endif; ?>



</section>
