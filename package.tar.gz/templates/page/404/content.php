<?php
$hero = get_field("404-hero", "option")["hero"];
?>

<?php get_template_part("template-parts/global/hero", null, array("hero" => $hero)); ?>
</section>
