<!--/ .related-blogs -->
<section class="related-blogs section content-row">

	<div class="wrap">

		<div class="section__title">
			<h2><?php _e('Related blogs', 'dtch'); ?></h2>
		</div>

		<div class="section__content">

			<div class="post-container col-3-grid small-gap">

				<?php 
					$query = new WP_Query ( array(
						'post_type' 		=> 'post',
						'post_status' 		=> 'publish',
						'posts_per_page' 	=> 3,
						'post__not_in'		=> array( $post->ID )
					));

					if ( $query->have_posts() ) : 

						while( $query->have_posts() ) : $query->the_post();

							get_template_part('templates/post/loop/summary'); 

						endwhile;

					endif;

					wp_reset_postdata();
				?>
				
			</div>

		</div>

	</div>

</section>
<!--/ #related-blogs -->