<section id="blog-comments" class="content-row white-bg">

	<div class="wrap">

		<div class="text-wrap align-center center-align">

			<h2><?php _e('Comments on this blog', 'dtch'); ?></h2>

			<div class="comments-count">

				<?php if( get_comments_number() > 0 ) : ?>

					<p><?php printf( _n( 'There is %s comment.', 'There are %s comments.', get_comments_number(), 'dtch'), number_format_i18n( get_comments_number() )  ); ?></p>

				<?php else : ?>

					<p><?php _e('No comments yet.', 'dtch'); ?></p>

				<?php endif; ?>			

			</div>

			<?php 
				comments_template();

				comment_form( array(
					'title_reply'			=> __('Leave a comment!', 'dtch'),
					'title_reply_before'	=> '<p class="h3">',
					'title_reply_after'		=> '</p>',
					'comment_notes_before'	=> '<p>' . __('The email address will not be published.', 'dtch') . '</p>'
				)); 
			?>

		</div>

	</div>

</section>