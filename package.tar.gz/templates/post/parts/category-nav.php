<?php $queried_object = get_queried_object(); ?>

<!--/ #blog-categories -->
<nav class="blog-categories">

	<select id="select-category" onchange="selectToUrl(this);"; >

		<option value="<?php the_permalink( get_option('page_for_posts') ); ?>"><?php _e('All categories', 'dtch'); ?></option>

		<?php 
			$categories = get_categories( array( 'hide_empty' => 0) ); 
			if( count($categories) > 0 ) :

				foreach( $categories as $cat ):

					$selected = '';
					if( is_category() && $queried_object->term_id == $cat->term_id )
						$selected = ' selected';

					echo '<option' . $selected . ' value="' . get_category_link($cat->term_id) . '">' . $cat->name . '</option>';

				endforeach;

			endif;
		?>

	</select>
</nav>
<!--/ #blog-categories -->