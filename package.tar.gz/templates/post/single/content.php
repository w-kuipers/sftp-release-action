<!--/ .single-post-section -->
<section class="single-post-section section content-row">

	<div class="wrap">

		<div class="single-post-section__content">

			<?php 
				get_template_part('template-parts/global/publish-info'); 
				
				the_title('<h1>', '</h1>');	

				echo apply_filters('the_content', add_indexable_content( get_the_content() ));
			?>

			<nav class="post-navigation button-wrap">
				<?php
					$next_post = get_next_post();
					$prev_post = get_previous_post();

					if( is_a( $prev_post, 'WP_Post' ) )
						echo '<a class="prev-post" href="' . get_permalink($prev_post->ID) . '"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>' . __('Previous article', 'dtch') . '</a>';

					if( is_a( $next_post, 'WP_Post') )
						echo '<a class="next-post" href="' . get_permalink($next_post->ID) . '">' . __('Next article', 'dtch') . '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>';
				?>
			</nav>

		</div>

		<aside id="blog-sidebar">

			<nav class="post-index">
				<p class="h3"><?php _e('Page index', 'dtch'); ?></p>
				<?= get_the_table_of_contents( get_the_content() ); ?>
			</nav>

			<div class="card blog-tags">
				<p class="h3"><?php _e('Tags', 'dtch'); ?></p>
				<?php
					$posttags = get_the_tags();
					if( $posttags ) {
						echo '	<ul>';
						foreach( $posttags as $term ) {
							echo '	<li>
										<a class="tag" href="'. get_term_link( $term, 'post_tag' ) . '" title="'. esc_attr( $term->name ) . '">
											'. $term->name . '
										</a>
									</li>';
						}
						echo '	</ul>';
					}
				?>
			</div>

			<div class="card blog-share">
				<p class="h3"><?php _e('Share this article', 'dtch'); ?></p>
				<?= do_shortcode('[social-media-share-buttons]'); ?>
			</div>

		</aside>

	</div>

</section>
<!--/ .single-post-section -->

<?php get_template_part('templates/post/parts/related-blogs'); ?>