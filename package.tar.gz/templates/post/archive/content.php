<?php $blogpage = get_post( get_option('page_for_posts') ); ?>

<!-- Start #archive-content -->
<section id="archive-content" class="section content-row">

	<div class="wrap">

		<?php 
			get_template_part('templates/post/parts/category-nav', NULL, array() ); 

			if( have_posts() ) :

				echo '<div id="post-container" class="row col-4-grid medium-gap">';

				while( have_posts() ) : the_post();

					get_template_part('templates/post/loop/summary'); 

				endwhile;

				echo '</div>';

				get_template_part('template-parts/global/pagination'); 

			else : 

				get_template_part('template-parts/global/no-items-found');
				
			endif; 
		?>		

	</div>
	
</section>
<!-- Start #archive-content -->
