<?php 
	$blogpage 		= get_post( get_option('page_for_posts') );
	$queried_object = get_queried_object(); 
?>

<!--/ #page-header -->
<section id="page-header" class="section content-row">

	<div class="wrap">

		<h1><?= ( is_home() ? get_the_title() : $queried_object->name ); ?></h1>

		<?= ( is_home() ? get_the_content() : apply_filters( 'the_content', $queried_object->description ) ); ?>

	</div>

</section>
<!--/ #page-header -->