<?php
$hero = get_field("hero")["hero"];
$form = get_field("form")["form"];
$featured_blogs = array(
	"title" => __("Innovations, success, stories & news")
);
$featured_products = array(
	"title" => __("Featured products")
);

?>

<?php get_template_part("template-parts/flexible/index"); ?>
<?php get_template_part("template-parts/flexible/rows/featured-products", null, array("content" => $featured_products)); ?>
<?php get_template_part("template-parts/flexible/rows/form", null, array("content" => $form)); ?>
<?php get_template_part("template-parts/flexible/rows/faq"); ?>
<?php get_template_part("template-parts/flexible/rows/featured-blogs", null, array("content" => $featured_blogs)); ?>
<?php get_template_part("template-parts/global/hero", null, array("hero" => $hero)); ?>
