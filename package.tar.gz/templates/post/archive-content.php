<?php
$queried_object = get_queried_object();
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$blogpage = get_post(get_option('page_for_posts'));
$hero = get_field("hero", $blogpage)["hero"];
$featured_products = get_field("featured-products", $blogpage)["featured_products"];
$image_cards = get_field("image-cards", $blogpage)["image_cards"];


$blogs = new WP_Query(array(
    "category_name" => $queried_object->slug,
    "posts_per_page" => 8,
    "orderby" => "date",
    "order" => "DESC",
    "paged" => $paged
));

$categories = get_categories();
?>

<?php get_template_part("template-parts/global/hero", null, array("hero" => $hero));  ?>
<section id="archive-content" class="section section-row">
	<div class="wrap">

		<?php if ($categories): ?>
			<div class="filters">
				<p class="filters-label"><?= __("Filter by:", "dtch") ?></p>
				
				<ul class="links">
					<?php foreach($categories as $cat): ?>
						<li><a href="<?= get_term_link($cat) ?>"><?= $cat->name ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>	
		<?php endif; ?>

		<?php if (have_posts()): ?>
			<div id="post-container" class="posts-container">
				<?php $c = 0; ?>
				<?php while ($blogs->have_posts()) : $blogs->the_post(); ?>

					<?php if ($c === 5): ?>
						<a href="#newsletter" class="post-cta anchor-link">
							<p><?= __("Subscribe here to our newsletter for the latest updates and offers.", "dtch"); ?></p>
							<button class="button outline"><?= __("Subscribe", "dtch"); ?></button>
						</a>
					<?php endif; ?>

					<article class="blog-summary">
						<a href="<?= get_the_permalink() ?>" class="post">
							<figure class="wrap-16-9">
								<?php foreach (get_the_category() as $category): ?>
									<div class="badge"><?= render_svg_icon("", "tag") ?><?= $category->name ?></div>
								<?php endforeach; ?>
								<?= wp_get_attachment_image(get_post_thumbnail_id(), "large", false, array("class" => "lazy")); ?>
							</figure>

							<div class="content">
								<p class="title"><?= the_title() ?></p>
								<p class="excerpt"><?= max_length(get_the_excerpt()); ?></p>
								<button class="button black"><?= __("Read more", "dtch"); ?></button>
							</div>
						</a>
					</article>
					<?php $c++; ?>
				<?php endwhile; ?>

				<?php if ($blogs->max_num_pages && $blogs->max_num_pages > 1) : ?>
					<nav class="pagination" role="navigation" aria-label="<?php esc_attr_e(__('Pagination navigation', 'dtch')); ?>">
						<?= paginate_links(array(
                            'base'			=> str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                            'format'		=> '/page/%#%/',
                            'current'		=> max(1, get_query_var('paged')),
                            'total'			=> $wp_query->max_num_pages,
                            'prev_text'     => render_svg_icon('', 'chevron-left'),
                            'next_text'     => render_svg_icon('', 'chevron-right')
                        )); ?>
					</nav>
				<?php endif; ?>
			</div>
		<?php else: ?>
			<?php get_template_part("template-parts/global/no-items-found"); ?>
		<?php endif; ?>

	</div>
	<?php get_template_part("template-parts/flexible/rows/featured-products", null, array("content" => $featured_products));  ?>
	<?php get_template_part("template-parts/flexible/rows/image-cards", null, array("content" => $image_cards));  ?>
	<?php get_template_part("template-parts/flexible/rows/reviews");  ?>
</section>
