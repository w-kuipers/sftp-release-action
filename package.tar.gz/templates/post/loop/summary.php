<?php
	$categories 	= get_the_category( $post->ID);
	$category 		= $categories[0];
?>

<article class="blog-summary">

	<header class="blog-summary__header">
		<h3>
			<a href="<?php the_permalink(); ?>" title="<?php esc_attr_e( get_the_title()); ?>">
				<?php the_title(); ?>
			</a>
		</h3>
	</header>

	<figure class="blog-summary__img">
		<a href="<?php the_permalink(); ?>" title="<?php esc_attr_e( get_the_title()); ?>">
			<?php the_post_thumbnail('medium', ['class' => ''] ); ?>
		</a>
	</figure>

	<p class="blog-summary__date smaller">
		<?php 
			printf( 
				__('%s in %s', 'dtch'), 
				'<time datetime="'.get_the_date('Y-m-d h:i').'">'. get_the_date() .'</time>',
				'<a href="'. get_category_link( $category->term_id ) .'" title="'. esc_attr( $category->name ) .'">'. $category->name .'</a>'	 
			); 
		?>
	</p>		

	<div class="blog-summary__excerpt">
		<?php the_excerpt(); ?>
	</div>

	<p class="button-wrap">
		<a class="button" href="<?php the_permalink(); ?>" title="<?php esc_attr_e( get_the_title() ); ?>">
			<?php _e('Read more', 'dtch'); ?>
		</a>
	</p>

</article>
