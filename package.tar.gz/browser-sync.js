const browserSync = require("browser-sync").create();

browserSync.init({
	proxy: "wordpress",
	files: [
		"./assets/**/*.css", // CSS files in the public directory
		"./assets/**/*.js", // JavaScript files in the public directory
		"**/*.php", // All PHP files in the project
		"!**/includes/**/*.php", // Exclude PHP files in any "includes" directory
	],
	snippetOptions: {
		ignorePaths: "wp-admin/**",
	},
	notify: false,
	open: false,
});
