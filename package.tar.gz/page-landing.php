<?php
// Template Name: Landingpage
// @package WordPress

get_header();
?>

<main id="main" role="main">
	<?php get_template_part("templates/page/landing/content"); ?>
</main>
<?php get_footer(); ?>
