<?php get_header(); ?>

<!-- Start #main -->
<main id="main" role="main">

	<?php get_template_part( 'templates/page/404/content' ); ?>

</main>
<!-- End #main -->

<?php get_footer(); ?>