<?php

// Combine classes into a single string
function concat_classes(...$classes)
{
    return implode(" ", $classes);
}

// Shorten string of text and add ... if its longer than a set number of characters
function max_length($string, $length = 120)
{
    if (strlen($string) > $length) {
        return substr($string, 0, $length) . "...";
    }

    return $string;
}
