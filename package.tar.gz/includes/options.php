<?php

/**
 * Change default CMS options
 */


// Change WP login logo
function dd_login_logo_one()
{

    if (class_exists('ACF')) {
        $global_info = get_field("global_info", "option");
        $logo = $global_info["logo"];

        echo '  <style type="text/css"> 
                    body.login {
                        background-color: #fff;
						background-image: url(' . get_template_directory_uri() . "/assets/img/background-shape.png" . ');
						background-repeat: no-repeat;
						background-position: 55% 14%;
  						background-size: 291rem;

                    }
                    
                    body.login #nav a, 
                    body.login #backtoblog a {
                        color: #FFF;
                    }

					#loginform {
						border-radius: 1rem;	
                        background-color: #fff;
						border-color: #fff;
						box-shadow: 0px 12px 49px -26px rgba(0, 0, 0, 0.2);
					}

                    body.login div#login h1 a {
                        background-image: url(' . wp_get_attachment_image_url($logo, "medium") . ');
                        background-color: transparent;
						border-color: #fff;
						
                        padding: 0;
                        margin: 0 auto 20px auto;
                        width: 170px;
                        height: 80px;
                        background-size: 170px 80px;
                    } 

                    body.login .message, 
                    body.login .success, 
                    body.login #login_error {
                        border-left: 4px solid #30beaa;
                    }

                    body.login a {
                        color: #FFF;
                    }

                    body.login input.button-primary {
                        background: #0075bf;
                        border-color: #0075bf;
                        color: #fff;
						font-weight: bold;
						border-radius: 10rem;
                    }
                </style>';
    }
}
add_action('login_enqueue_scripts', 'dd_login_logo_one');

// Optimize styling for cloned ACF fields
add_action('admin_head', 'acf_clone_styling');

function acf_clone_styling()
{
    echo '<style>
	.dd-content-block {
		padding: 0!important;
	}
	.dd-content-block >.acf-label {
		display: none;
	}

	.dd-content-block >.acf-input >.acf-fields {
		border: none;
	}
  </style>';
}

// Remove the username tag from the Twitter card necessary for Slack
function dd_yoast_remove_username_metatag($tag_arr)
{

    if (isset($tag_arr['Written by'])) {
        unset($tag_arr['Written by']);
    }
    return $tag_arr;
}
add_filter('wpseo_enhanced_slack_data', 'dd_yoast_remove_username_metatag');



// Remove margin top by WP toolbar (logged in only)
function remove_admin_login_header()
{
    remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_login_header');


// Remove the default WP auto redirect filter
add_filter('do_redirect_guess_404_permalink', '__return_false');
