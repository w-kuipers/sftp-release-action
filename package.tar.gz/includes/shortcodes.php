<?php
/*
 * All extra custom functions go inside this class, use this for image-sizes, ajax-callbacks et cetera
 *
 * @author Stef Dijkstra
 */

if (! class_exists('DD_Custom_Shortcodes')) {


	class DD_Custom_Shortcodes
	{
		public function __construct()
		{

			// Render site logo
			// Example usage: [logo]
			add_shortcode('logo', array($this, 'render_logo_func'));

			// Render site logo alternative
			// Example usage: [logo-alternative]
			add_shortcode('logo-alternative', array($this, 'render_logo_alternative_func'));

			// Render social media share buttons
			// Example usage: [social-media-share-buttons]
			add_shortcode('social-media-share-buttons', array($this, 'social_media_share_buttons_func'));

			// Render social media buttons
			// Example usage: [social-media-icons]
			add_shortcode('social-media-icons', array($this, 'social_media_icons_func'));

			// Shortcode for rendering button
			// Example usage: [button url="#" text="Button text" size="large" color="green" icon="chevron-right" target="_blank" anchor="true"]
			add_shortcode('button', array($this, 'button_func'));

			// Shortcode for renderin more link
			// Example usage: [more-button url="#" text="Button text" ]
			add_shortcode('more-button', array($this, 'more_button_func'));

			// Shortcode for rendering embed-video
			// Example usage: [embed-video url="https://www.youtube.com/embed/fFyCHQRK9hQ"]
			add_shortcode('embed-video', array($this, 'embed_video_func'));

			// Shortcode for rendering embed-video with image placeholder
			// Example usage: [embed-video-image url="https://www.youtube.com/embed/fFyCHQRK9hQ" img_id="1"]
			add_shortcode('embed-video-image', array($this, 'embed_video_with_image_func'));

			// Render search form
			// Example usage: [search-form]
			add_shortcode('search-form', array($this, 'render_search_func'));

			// Render stars with Font Awesome
			// Example usage: [stars score="5"]
			add_shortcode('stars', array($this, 'render_stars_func'));
		}


		// Render site logo
		public function render_logo_func()
		{
			$html = '';
			ob_start();
			get_template_part('template-parts/shortcodes/site-logo');
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}


		// Render site logo diapositive
		public function render_logo_alternative_func()
		{
			$html = '';
			ob_start();
			get_template_part('template-parts/shortcodes/site-logo-alternative');
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}


		// Render site logo
		public function render_search_func()
		{
			$html = '';
			ob_start();
			get_template_part('template-parts/shortcodes/search-form');
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}


		// Render social media share buttons
		public function social_media_share_buttons_func()
		{

			$content = '';

			$url       = get_permalink(get_the_ID());
			$title     = urlencode(get_the_title(get_the_ID()));
			$image_url = '';
			$image_id  = get_post_thumbnail_id(get_the_ID());
			if (isset($image_id) && (! empty($image_id))) {

				$image = wp_get_attachment_image_src($image_id, 'large');

				if (is_array($image) && (! empty($image))) {
					$image_url = $image[0];
				}
			}

			//Twitter
			$twitter_url = 'https://twitter.com/intent/tweet';
			$twitter_url = add_query_arg('text', $title, $twitter_url);
			$twitter_url = add_query_arg('url', $url, $twitter_url);

			//Facebook
			$facebook_url = 'https://www.facebook.com/sharer/sharer.php';
			$facebook_url = add_query_arg('u', $url, $facebook_url);

			//Google
			$google_url = 'https://plus.google.com/share';
			$google_url = add_query_arg('url', $url, $google_url);

			//Whatsapp
			$whatsapp_url = 'whatsapp://send';
			$whatsapp_url = add_query_arg('text', $title . ' ' . $url, $whatsapp_url);

			//LinkedIn
			$linkedin_url = 'https://www.linkedin.com/shareArticle';
			$linkedin_url = add_query_arg('mini', 'true', $linkedin_url);
			$linkedin_url = add_query_arg('url', $url, $linkedin_url);
			$linkedin_url = add_query_arg('title', $title, $linkedin_url);

			//Pinterest
			$pinterest_url = 'https://pinterest.com/pin/create/button/';
			$pinterest_url = add_query_arg('url', $url, $pinterest_url);
			$pinterest_url = add_query_arg('description', $title, $pinterest_url);
			$pinterest_url = add_query_arg('media', $image_url, $pinterest_url);

			//Mail
			$mail_url = 'mailto:';
			$mail_url = add_query_arg('subject', $title, $mail_url);
			$mail_url = add_query_arg('body', urlencode(__('View this website:', 'dtch') . ' ' . $url), $mail_url);

			$content .= '	<ul class="sm-share-buttons">
								<li class="twitter">
									<a href="' . $twitter_url . '" target="_blank" title="' . esc_attr__('Share on Twitter', 'dtch') . '" rel="noreferrer noopener" aria-label="' . esc_attr__('Share on Twitter', 'dtch') . '">
										' . render_svg_icon('', 'twitter') . '
									</a>
								</li>
								<li class="facebook">
									<a href="' . $facebook_url . '" target="_blank" title="' . esc_attr__('Share on Facebook', 'dtch') . '" rel="noreferrer noopener" aria-label="' . esc_attr__('Share on Facebook', 'dtch') . '">
										' . render_svg_icon('', 'facebook') . '
									</a>
								</li>
								<li class="linkedin">
									<a href="' . $linkedin_url . '" target="_blank" title="' . esc_attr__('Share on LinkedIn', 'dtch') . '" rel="noreferrer noopener" aria-label="' . esc_attr__('Share on LinkedIn', 'dtch') . '">
										' . render_svg_icon('', 'linkedin') . '
									</a>
								</li>
								<li class="email">
									<a href="' . $mail_url . '" title="' . esc_attr__('Share by e-mail', 'dtch') . '" aria-label="' . esc_attr__('Share by e-mail', 'dtch') . '">
										' . render_svg_icon('', 'mail') . '
									</a>
								</li>
								<li class="whatsapp">
									<a href="' . $whatsapp_url . '" title="' . esc_attr__('Share on Whatsapp', 'dtch') . '" aria-label="' . esc_attr__('Share on Whatsapp', 'dtch') . '">
										' . render_svg_icon('', 'whatsapp') . '
									</a>
								</li>
							</ul>';

			return $content;
		}


		// Render social media icons
		public function social_media_icons_func()
		{

			$html = '';

			if (class_exists('ACF')) {
				if (have_rows('social_media', 'option')) :
					$html .= '	<ul class="sm-icons">';

					while (have_rows('social_media', 'option')) : the_row();

						$name = strtolower(get_sub_field('network'));

						$html .= '	<li class="' . sanitize_title($name) . ' sm-list__item">
										<a href="' . get_sub_field('url') . '" title="' . __('Visit our', 'dtch') . ' ' .  ucfirst(esc_attr($name)) . '" target="_blank" rel="noreferrer noopener" class="sm-icons__link">
											' . render_svg_icon('', $name) . '
										</a>
									</li>';

					endwhile;

					$html .= '	</ul>';

				endif;
			}

			return $html;
		}


		// Shortcode for rendering button
		public function button_func($atts)
		{

			$color		= '';
			$text		= '';
			$url		= '';
			$target		= '';
			$size 		= '';
			$icon 		= '';
			$icon_position = '';
			$anchor 	= '';
			$wrap_start	= '<p>';
			$wrap_end 	= '</p>';

			if (isset($atts['color']) && $atts['color'] !== '') {
				$color = ' ' . $atts['color'];
			}

			if (isset($atts['size']) && $atts['size'] !== '') {
				$size = ' ' . $atts['size'];
			}

			if (isset($atts['url']) && $atts['url'] !== '') {
				$url = $atts['url'];
			}

			if (isset($atts['text']) && $atts['text'] !== '') {
				$text = esc_attr($atts['text']);
			}

			if (isset($atts['anchor']) && $atts['anchor'] == 'true' || substr($url, 0, 1) === "#") {
				$anchor = ' anchor-link';
			}

			if (isset($atts['target']) && $atts['target'] == '_blank') {
				$target = ' target="' . $atts['target'] . '" rel="noreferrer noopener"';
			}

			if (isset($atts['icon']) && $atts['icon'] !== '') {
				$icon = '<span class="button__icon">' . render_svg_icon('', $atts['icon']) . '</span>';
			}

			if (isset($atts['icon-position']) && $atts['icon-position'] == 'right') {
				$icon_position = ' reversed';
			}

			if (isset($atts['wrap']) && $atts['wrap'] == 'false') {
				$wrap_start	= '';
				$wrap_end 	= '';
			}

			$html = $wrap_start . '<a title="' . strip_tags($text) . '" class="button' . $color . $anchor . $size . '" href="' . $url . '"' . $target . '><span class="button__container' .  $icon_position . '">' . $icon . '<span class="button__text">' . $text . '</span></span></a>' . $wrap_end;

			return $html;
		}

		// Shortcode for rendering button
		public function more_button_func($atts)
		{

			$text		= '';
			$url		= '';
			$target		= '';

			if (isset($atts['url']) && $atts['url'] !== '') {
				$url = $atts['url'];
			}

			if (isset($atts['text']) && $atts['text'] !== '') {
				$text = esc_attr($atts['text']);
			}

			if (isset($atts['target']) && $atts['target'] == '_blank') {
				$target = ' target="' . $atts['target'] . '" rel="noreferrer noopener"';
			}


			$html = '<p><a title="' . strip_tags($text) . '" class="more-button" href="' . $url . '"' . $target . '><span class="more-button__text">' . $text . '</span><span class="more-button__icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span></a></p>';

			return $html;
		}


		// Shortcode for rencering embed-video
		public function embed_video_func($atts)
		{

			$html = '';

			if (isset($atts['url']) && $atts['url'] !== '') {
				$url = $atts['url'];
				$html .= '	<p class="responsive-iframe-wrapper">
								<iframe title="' . esc_attr(__('Play video', 'dtch')) . '" class="lazy" data-src="' . $url . '"></iframe>
							</p>';
			} else {
				$html .= __('No url inserted', 'dtch');
			}

			return $html;
		}


		// Shortcode for rencering embed-video-with-image
		public function embed_video_with_image_func($atts)
		{
			$html = '';
			$img = '';

			if (isset($atts['img_id']) && $atts['img_id'] !== '') {
				$img = wp_get_attachment_image($atts['img_id'], 'desktop', false, ['class' => '']);
			}

			if (isset($atts['url']) && $atts['url'] !== '') {
				$url = $atts['url'];
				$html .= '	<p class="responsive-video-wrapper">
								<a class="video-wrapper" href="javascript:;" title="' . esc_attr(__('Play video', 'dtch')) . '">
									' . $img . '
									<iframe class="lazy-iframe" title="' . esc_attr(__('Play video', 'dtch')) . '" data-src="' . $url . '?autoplay=1&mute=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
									<span class="play-button">' . render_svg_icon("", "play") . '</span>
								</a>
							</p>';
			} else {
				$html .= __('No url inserted', 'dtch');
			}

			return $html;
		}


		// Set integer to stars
		public function render_stars_func($atts)
		{

			$html = '<span class="star-container">';

			$score  		= $atts['score'];
			$amount 		= floor($score * 2) / 2;
			$stars 			= $amount / 2;
			$full_stars 	= floor($stars);
			$starcount 		= 0;
			$half_star_set = false;

			//star end is not a full
			for ($i = 1; $i <= 5; $i++) {

				if ($i <= $full_stars) {

					$html .= render_svg_icon('star-container__star star-container__star--full', 'star');
					$starcount++;
				} else {

					if ($starcount == $full_stars && $starcount != 5) {
						if (is_numeric($stars) && floor($stars) != $stars && !$half_star_set) {
							$html .= render_svg_icon('star-container__star star-container__star--half', 'star-half');
							$half_star_set = true;
						} else {
							$html .= render_svg_icon('star-container__star star-container__star--empty', 'star-empty');
						}
					}
				}
			}

			$html .= ' </span>';

			return $html;
		}
	}
}
