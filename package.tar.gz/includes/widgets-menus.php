<?php

// Register nav menu theme-locations
register_nav_menus(
	array(
		'main-navigation'       => __('Main navigation', 'dtch'),
		'mobile-navigation'     => __('Mobile navigation', 'dtch'),
		'language-navigation'     => __('Language navigation', 'dtch')
	)
);


// Add default title to <a> in menu's
add_filter('nav_menu_link_attributes', 'dd_add_default_title_to_menu_link', 10, 3);
function dd_add_default_title_to_menu_link($atts, $item, $args)
{

	if (!$item->attr_title) {
		$atts['title'] =  $item->title;
	}

	return $atts;
}


// Add class to footer menu
add_filter('wp_nav_menu_objects', 'dd_wp_menu_objects', 10, 2);
function dd_wp_menu_objects($items, $args)
{

	if ($args->theme_location == 'footer-navigation') {
		foreach ($items as $item) {
			$item->classes[] = 'smaller';
		}
	}

	return $items;
}

// Disable active state from CTP single page for blog page
add_filter('nav_menu_css_class', 'remove_current_page_parent_class', 10, 2);

function remove_current_page_parent_class($classes, $item)
{

	$post_types         = get_post_types(array('public' => true, '_builtin' => false), 'names');
	$current_post_type  = get_post_type();

	if ($current_post_type) {
		if (array_key_exists($current_post_type, $post_types)) {

			if (is_singular() || is_archive()) {

				// Get the ID of the page for posts
				$page_for_posts_id = get_option('page_for_posts');

				// Remove the "current_page_parent" class from the page for posts
				if ((int)$item->object_id === (int)$page_for_posts_id) {
					$classes = array_diff($classes, array('current_page_parent'));
				}
			}
		}
	}

	return $classes;
}
