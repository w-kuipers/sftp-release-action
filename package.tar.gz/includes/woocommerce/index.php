<?php 

/**
   * Default WooCommerce changes
*/

  
 /** Uncomment options below before acitvating Woocommerce. **/
 add_theme_support( 'woocommerce' );
 //add_theme_support( 'wc-product-gallery-zoom' );
 //add_theme_support( 'wc-product-gallery-lightbox' );
 add_theme_support( 'wc-product-gallery-slider' );


require_once( get_template_directory() . '/includes/woocommerce/functions.php' );

require_once( get_template_directory() . '/includes/woocommerce/general.php' );

require_once( get_template_directory() . '/includes/woocommerce/order-customs.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/email.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/archive.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/single.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/cart.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/checkout.php' );

require_once( get_template_directory() . '/includes/woocommerce/templates/account.php' );