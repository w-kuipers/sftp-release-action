<?php 

/**
   *  Woocommerce general addings
*/

// Disable default WooCommerce CSS
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );


// Replace the Woocommerce breadcrumbs by the Yoast breadcrumbs
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);


// Wrap the WC content
add_action( 'woocommerce_before_main_content', function() {
   echo '   <div id="woocommerce-content" class="content-row bg-creme">';
   get_template_part('template-parts/global/breadcrumbs');
   echo '      <div class="wrap">';
}, 10 );


add_action( 'woocommerce_after_main_content', function() {
   echo '       </div>
            </div>';
}, 10 );