<?php 

/**
   *  Add custom functions Woocommerce
*/