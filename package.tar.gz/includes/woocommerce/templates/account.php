<?php 

/**
   * Woocommerce account
*/

// Change login text
add_action( 'woocommerce_login_form_start','dd_add_login_text' );  
function dd_add_login_text() {
   if ( is_checkout() ) return;
   echo '<h3 class="form-title">'. __('Existing customer', 'dtch') . '</h3>';
}

add_action( 'woocommerce_register_form_start','dd_add_reg_text' ); 
function dd_add_reg_text() {
   echo '<h3 class="form-title">'. __('Create an account?', 'dtch') . '</h3>';
}