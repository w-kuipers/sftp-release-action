<?php 

/**
   * Woocommerce archive
*/


// Remove sidebar
function disable_woo_commerce_sidebar() {
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10); 
}
add_action('init', 'disable_woo_commerce_sidebar');

// Wrap the product loop
add_action( 'woocommerce_before_main_content', function() {
    if ( is_archive() || is_shop() )  {

        echo '   <div id="shop-archive-container">
                    <div id="products-overview">';
    }
}, 20 );

add_action( 'woocommerce_after_shop_loop', function() {
    if ( is_archive()  || is_shop() )  {
        echo '      </div><!--/ #products-overview -->';
    }
}, 30 );

// Add sidebar after product overview
add_action( 'woocommerce_after_shop_loop', function() {
    if( is_archive() || is_shop() ) {
        echo '  <aside id="shop-sidebar">';
                    dynamic_sidebar('shop_sidebar');
        echo '      <div class="mob-only">
                        <p class="button-wrap">
                            <button class="button" onclick="toggleMobFilters();" title="'. esc_attr( __('Hide filters', 'dtch') ) . '">
                                <span class="icon">'. render_svg_icon( '', 'x' ) .'</span>
                                <span class="text">'. __('Hide filters', 'dtch') . '</span>
                            </button>    
                        </p>
                    </div>';
        echo '  </aside>'; 
    }
}, 30 );

add_action( 'woocommerce_after_shop_loop', function() {
    if ( is_archive()  || is_shop() )  {
        echo '      </div><!--/ #shop-archive-container -->';
    }
}, 30 );


// Wrap woocommerce result options
add_action( 'woocommerce_before_shop_loop', function() {
    echo '  <div class="mob-only">
                <p class="button-wrap">
                    <button class="button" onclick="toggleMobFilters();" title="'. esc_attr( __('Filter results', 'dtch') ) . '">
                        <span class="icon">'. render_svg_icon( '', 'filter' ) .'</span>
                        <span class="text">'. __('Filter results', 'dtch') . '</span>
                    </button>    
                </p>
            </div>';
   echo '   <nav class="woocommerce-result-options">'; 
}, 10 );

add_action( 'woocommerce_before_shop_loop', function() {
   echo '   </nav>'; 
}, 40 );


// Change the h2 loop to h3
if ( ! function_exists( 'woocommerce_template_loop_product_title' ) ) {
    function woocommerce_template_loop_product_title() {
        echo '<p class="woocommerce-loop-product__title">' . get_the_title() . '</p>';
    }
}

if ( ! function_exists( 'woocommerce_template_loop_category_title' ) ) {
    function woocommerce_template_loop_category_title(  $category ) {
        echo '  <span class="button">' . $category->name . '</span>';
    }
}

// Wrap the featured images 
add_action( 'woocommerce_before_shop_loop_item_title', function(){
    echo '  <figure class="feat-img">';
}, 9 );
add_action( 'woocommerce_before_shop_loop_item_title', function(){
    echo '  </figure>';
}, 11 );


// Wrap buttons
add_action('woocommerce_after_shop_loop_item', function() {
    echo '<div class="button-wrap">';
}, 9);


add_action('woocommerce_after_shop_loop_item', function() {
    echo '</div>';
}, 15);

// Add flexible content to archive pages
add_action('woocommerce_after_main_content', 'add_flexible_content', 30);
function add_flexible_content() {

    $queried_object = get_queried_object();

    if( have_rows('flex_content', $queried_object ) ) :

        while ( have_rows( 'flex_content', $queried_object ) ) : the_row();

            get_template_part('template-parts/flexible/rows/' . get_row_layout() );

        endwhile;
        
    endif;
}
