<?php 

/**
   *  Woocommerce cart
*/


// Action to get uncached cart
function load_woo_cart(){
    echo get_template_part( 'template-parts/woocommerce/parts/cart-amount' );
    die();
}
add_action( 'wp_ajax_nopriv_load_woo_cart', 'load_woo_cart' );
add_action( 'wp_ajax_load_woo_cart', 'load_woo_cart' );


// Auto update cart in Cart page
add_action( 'wp_footer', 'dd_cart_refresh_update_qty' );  
function dd_cart_refresh_update_qty() { 
    if ( is_cart() ) { 
        echo '  <script type="text/javascript"> 
                    jQuery(\'div.woocommerce\').on(\'focusout\', \'input.qty\', function(){ 
                        jQuery("[name=\'update_cart\']").trigger("click"); 
                    }); 
                </script>';
    } 
}

// Remove cross-sells at cart
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );


// Custom cart count
add_action( 'woocommerce_add_to_cart', 'dd_set_cart_amount_cookie' );
add_action( 'woocommerce_cart_updated', 'dd_set_cart_amount_cookie' );
add_action( 'woocommerce_after_cart_item_removed', 'dd_set_cart_amount_cookie_after_item_removed', 10, 2 );
add_action( 'wp_login', 'dd_set_cart_amount_cookie', 10, 2 );

function dd_set_cart_amount_cookie() {

    global $woocommerce;

    $cart_count     = 0;

    if ( $woocommerce->cart->cart_contents_count > 0 ) {
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            $product = $cart_item['data'];
            $cart_count += $cart_item['quantity'];
        }
    }
    
    setcookie( 'woocommerce_amount_in_cart', $cart_count, time() + 3600, COOKIEPATH, COOKIE_DOMAIN );   
}

add_action('woocommerce_thankyou', 'dd_clear_cart_amount_cookie_thank_you_page');
function dd_clear_cart_amount_cookie_thank_you_page( $order_id ) {
    if (isset($_COOKIE['woocommerce_amount_in_cart'])) {
        setcookie('woocommerce_amount_in_cart', '', time() - 3600, '/');
    }
}


//Add quantity controls
add_action( 'woocommerce_before_quantity_input_field', 'dd_before_quantity_controls' );
function dd_before_quantity_controls() {
    echo '  <div class="quantity__controls">';
    echo '      <button type="button" class="quantity__button quantity__button--minus minus"  onclick="numberDown(this);">-</button>';
}

add_action( 'woocommerce_after_quantity_input_field', 'dd_after_quantity_controls' );
function dd_after_quantity_controls() {
    echo '      <button type="button" class="quantity__button quantity__button--plus plus"  onclick="numberUp(this);">+</button>';
    echo '  </div>';
}


