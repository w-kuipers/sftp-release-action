<?php 

/**
   *  Woocommerce checkout
*/


add_action('woocommerce_checkout_after_customer_details', 'start_checkout_order_wrap', 0);
function start_checkout_order_wrap() {
    echo '  <!--/ #checkout-order-wrap -->
            <div id="checkout-order-wrap">';
}

add_action('woocommerce_checkout_after_order_review', 'end_checkout_order_wrap', 50);
function end_checkout_order_wrap() {
    echo '  </div>
            <!--/ #checkout-order-wrap -->';
}

add_action('woocommerce_review_order_before_payment', function() {
    echo '<div id="order-confirmation-wrapper">';
}, 0);

add_action( 'woocommerce_review_order_before_payment', function(){
    echo '  <p class="h3">' . __('Payment method', 'dtch') . '</p>'; 
}, 10 );


add_action('woocommerce_review_order_after_submit', function() {
    echo '</div>';
}, 0);