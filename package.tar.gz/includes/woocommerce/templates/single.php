<?php 

/**
   *  Woocommerce single product
*/


// Update WooCommerce Flexslider options
add_filter( 'woocommerce_single_product_carousel_options', 'dd_update_woo_flexslider_options' );
function dd_update_woo_flexslider_options( $options ) {
  $options['directionNav']    = true;
  $options['controlNav']      = false;
  $options['prevText']        = render_svg_icon('chevron-left', '' );
  $options['nextText']        = render_svg_icon('chevron-right', '' );
  $options['sync']            = '#thumbnail-slider';
  return $options;
}


// Add Fancybox link to product gallery
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'filter_woocommerce_single_product_image_thumbnail_html', 10, 2 );
function filter_woocommerce_single_product_image_thumbnail_html( $sprintf, $post_id ) { 
        $original = $sprintf;
        $sprintf = str_replace( '<a', '<a data-fancybox="gallery"', $original );
        return $sprintf; 
};  


// Wrap the product images gallery
add_action( 'woocommerce_before_single_product_summary', 'dtch_single_product_header', 1);

function dtch_single_product_header() {
    echo '      <!--/ #single-product-header -->
                <section id="single-product-header">
                        <div id="single-product-gallery">';
}


// Add custom thumbnail navigation for gallery
add_action( 'woocommerce_before_single_product_summary', 'add_product_thumbs_slider', 50 );
function add_product_thumbs_slider() {
   get_template_part('template-parts/woocommerce/parts/product-thumbnails');
}

add_filter( 'woocommerce_single_product_carousel_options', 'filter_single_product_carousel_options' );
function filter_single_product_carousel_options( $options ) {
        $options['prevText'] = render_svg_icon( '', 'chevron-left');
        $options['nextText'] = render_svg_icon( '', 'chevron-right');
        return $options;
}

add_action( 'woocommerce_before_single_product_summary', function() {
        echo '  </div>
                <!--/ #single-product-gallery -->';
}, 50);

add_action( 'woocommerce_after_single_product_summary', function() {
        echo '  </section>
                <!--/ #end single-products-header -->';
}, 0);