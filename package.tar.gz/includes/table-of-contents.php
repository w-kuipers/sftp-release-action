<?php

global $table_of_contents;
$table_of_contents = array();

// Add content to the table of contents array
function indexable_content($content)
{

	$index = get_query_var("index", 1);
	$content = preg_replace_callback('#<(h[2-3])(.*?)>(.*?)</\1>#si', function ($matches) use (&$index) {
		global $table_of_contents;
		$tag = $matches[1];
		$title = strip_tags($matches[3]);

		if (!$title) {
			return $content;
		}

		$hasId = preg_match('/id=(["\'])(.*?)\1[\s>]/si', $matches[2], $matchedIds);
		$id = $hasId ? $matchedIds[2] : $index++ . '-' . bin2hex(random_bytes(10));

		array_push($table_of_contents, array(
			"title" => $title,
			"id" => $id
		));

		if ($hasId) {
			return $matches[0];
		}

		return sprintf('<%s%s id="%s">%s</%s>', $tag, $matches[2], $id, $matches[3], $tag);
	}, $content);
	set_query_var('index', $index);

	return $content;
}

// Add title to the table of contents array
function indexable_title($title)
{
	if (!$title) {
		return "";
	}

	global $table_of_contents;
	$index = get_query_var("index", 1);
	$id = $index++ . "-" . bin2hex(random_bytes(10));

	array_push($table_of_contents, array(
		"title" => $title,
		"id" => $id
	));

	set_query_var('index', $index);

	return $id;
}
