(function() {
	tinymce.PluginManager.add("addbutton", function(editor, url) {
		editor.addButton("addbutton", {
			title: tinyMCE_object.button_title,
			image: url + "/icon-button.svg",
			onclick: function() {
				editor.windowManager.open({
					title: tinyMCE_object.button_title,
					body: [
						{
							type: "textbox",
							name: "button_text",
							label: "Button tekst",
						},
						{
							type: "textbox",
							name: "button_url",
							label: "URL",
						},
						{
							type: "listbox",
							name: "button_color",
							label: "Kies een kleur",
							values: [
								{ text: "Blauw", value: "blue" },
								{ text: "Zwart", value: "black" },
								{ text: "Outline", value: "outline" },
							],
							value: "black", // Sets the default
						},
						{
							type: "checkbox",
							name: "button_anchor",
							text: "Dit is een ankerlink.",
							value: "true",
							label: "Anker link?",
						},
						{
							type: "listbox",
							name: "button_target",
							label: "Soort link",
							values: [
								{ text: "Intern", value: "_self" },
								{ text: "Extern", value: "_blank" },
							],
							value: "_self", // Sets the default
						},
					],
					onsubmit: function(e) {
						var params = [];

						if (e.data.button_text.length > 0) {
							params.push('text="' + e.data.button_text + '"');
						}

						if (e.data.button_color.length > 0) {
							params.push('color="' + e.data.button_color + '"');
						}

						if (e.data.button_url.length > 0) {
							params.push('url="' + e.data.button_url + '"');
						}

						if (e.data.button_target.length > 0) {
							params.push('target="' + e.data.button_target + '"');
						}

						if (e.data.button_anchor) {
							params.push('anchor="true"');
						}

						if (params.length > 0) {
							paramsString = " " + params.join(" ");
						}

						editor.insertContent("[button" + paramsString + "]");
					},
				});
			},
		});

		editor.addButton("addvideobutton", {
			title: tinyMCE_object.video_button_title,
			image: url + "/icon-video.svg",
			onclick: function() {
				editor.windowManager.open({
					title: tinyMCE_object.video_button_title,
					body: [
						{
							type: "textbox",
							name: "embed_url",
							label: "Embed url",
						},
					],
					onsubmit: function(e) {
						editor.insertContent('[embed-video url="' + e.data.embed_url + '"]');
					},
				});
			},
		});
	});
})();
