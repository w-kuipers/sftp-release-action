<?php

/**
 * Add image sizes and customs
 */

// Add extra image sizes
add_image_size('small', 320, 320, false);
add_image_size('desktop', 1920, 1080, false);
add_filter('image_size_names_choose', 'dd_custom_sizes');

function dd_custom_sizes($sizes)
{
	return array_merge($sizes, array(
		'small'         => __('Small', 'dtch'),
		'desktop'       => __('Desktop', 'dtch'),
	));
}


// Set default image info after uploading image
add_action('add_attachment', 'set_image_meta_upon_image_upload');

function set_image_meta_upon_image_upload($post_ID)
{

	// Check if uploaded file is an image, else do nothing
	if (wp_attachment_is_image($post_ID)) {

		$img_title = get_post($post_ID)->post_title;
		$img_title = preg_replace('%\s*[-_\s]+\s*%', ' ', $img_title);
		$img_title = ucwords(strtolower($img_title));

		$image_meta = array(
			'ID'            => $post_ID,
			'post_title'    => $img_title,
			//'post_excerpt'  => $img_title, == Default caption
			//'post_content'  => $img_title == Default description
		);

		// Set the image Alt-Text
		update_post_meta($post_ID, '_wp_attachment_image_alt', $img_title);

		// Set the image meta (e.g. Title, Excerpt, Content)
		wp_update_post($image_meta);
	}
}


// Add lazy loading functionality to images
add_filter('wp_get_attachment_image_attributes', 'add_lazyload_to_attachment_image', 10, 2);
function add_lazyload_to_attachment_image($attr, $attachment)
{

	$lazy       = strstr($attr['class'], 'lazy');

	if ($lazy) {
		$attr['data-src'] = $attr['src'];
		$attr['src'] = '';

		if (isset($attr['srcset'])) :
			$attr['data-srcset'] = $attr['srcset'];
			$attr['srcset'] = '';
		endif;
	}

	return $attr;
}



// Show Image ID column to media library (list view)
add_filter('manage_media_columns', 'posts_columns_attachment_id', 1);

add_action('manage_media_custom_column', 'posts_custom_columns_attachment_id', 1, 2);

function posts_columns_attachment_id($defaults)
{
	$defaults['wps_post_attachments_id'] = __('Image ID', 'dtch');
	return $defaults;
}

function posts_custom_columns_attachment_id($column_name, $id)
{
	if ($column_name === 'wps_post_attachments_id')
		echo $id;
}

//Render default theme svg icon
function render_svg_icon($class_name, $icon_name)
{

	$transient_key  = 'svg_icon_' . $icon_name . ($class_name ? '_' . $class_name : '');
	$svg            = get_transient($transient_key);

	if (true) {
		// if ( false === $svg ) {

		$svg_path = get_template_directory() . '/assets/img/icons/' . $icon_name . '.svg';

		if (file_exists($svg_path)) {

			$svg = file_get_contents($svg_path);

			if ($class_name) {
				if (str_contains($svg, 'class="')) {
					$svg = str_replace('class="', 'class="' . $class_name . ' ', $svg);
				} else {
					$svg = str_replace('<svg', '<svg class="' . $class_name . '"', $svg);
				}
			}

			set_transient($transient_key, $svg, DAY_IN_SECONDS);
		} else {

			return false;
		}
	}

	return $svg;
}


//Render custom svg icon
function render_svg($class_name, $svg_path)
{

	$info           = pathinfo($svg_path);
	$icon_name      = $info['filename'];

	$transient_key  = 'svg_icon_' . $icon_name . ($class_name ? '_' . $class_name : '');
	$svg            = get_transient($transient_key);

	if (false === $svg) {

		if (file_exists($svg_path)) {

			$svg = file_get_contents($svg_path);

			if ($class_name) {

				if (str_contains($svg, 'class="')) {
					$svg = str_replace('class="', 'class="' . $class_name . ' ', $svg);
				} else {
					$svg = str_replace('<svg', '<svg class="' . $class_name . '"', $svg);
				}
			}

			set_transient($transient_key, $svg, DAY_IN_SECONDS);
		} else {

			return false;
		}
	}

	return $svg;
}

