<?php

/**
   * Enqueue scripts
*/

// Adding CSS + JS files
add_action( 'wp_enqueue_scripts', 'dd_enqueue_scripts_styles' );
function dd_enqueue_scripts_styles() {

    // Add default jQuery library to theme
    wp_enqueue_script( 'jquery' );

    // Load Vendor files
    foreach ( glob( get_template_directory()  . '/assets/js/vendor/*.js' ) as $file ) {  
        $script     = str_replace( get_template_directory(), get_template_directory_uri(), $file);
        $name       = sanitize_title( basename( $script ));
        wp_enqueue_script( 'dd-'. $name,  $script, array( 'jquery' ), false, true );
    }

    // Add custom theme JS file
    $version = filemtime( trailingslashit( get_template_directory() ) . 'assets/js/main.js' );
    wp_enqueue_script( 'dd-scripts',  trailingslashit( get_template_directory_uri() ) . 'assets/js/main.js', array( 'jquery' ), $version, true );

    // Load vendor CSS scripts
    foreach ( glob( get_template_directory()  . '/assets/css/vendor/*.css' ) as $file ) {  
        $script     = str_replace( get_template_directory(), get_template_directory_uri(), $file);
        $name       = sanitize_title( basename( $script ));
        wp_enqueue_style( 'dd-'. $name, $script, array(), '1.0.0', 'all');
    }

    // Add custom theme CSS file
    $version = filemtime( trailingslashit( get_template_directory() ) . 'assets/css/dd_style.css' );
    wp_enqueue_style( 'dd-style', trailingslashit( get_template_directory_uri() ) . 'assets/css/dd_style.css', array(), $version, 'all');
    
    // Add ajax URL to theme
    // wp_localize_script('dd-scripts', 'ajax_object', array(
    //     'ajax_nonce'    => wp_create_nonce('ajax_nonce'),
    //     'ajax_url'      => admin_url('admin-ajax.php')
    // ));

    //if( defined( 'GOOGLE_MAPS_API_KEY' ) )
        //wp_enqueue_script( 'dd-google-maps', 'https://maps.googleapis.com/maps/api/js?key='. GOOGLE_MAPS_API_KEY, false, NULL, true );     
}


// Disable jQuery migrate on front
function dequeue_jquery_migrate( $scripts ) {
    if ( ! is_admin() && ! empty( $scripts->registered['jquery'] ) ) 
        $scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, [ 'jquery-migrate' ] );
}
add_action( 'wp_default_scripts', 'dequeue_jquery_migrate' );


// Disable default gallery css
add_filter( 'use_default_gallery_style', '__return_false' );


// Disable native WP lazy loading
add_filter( 'wp_lazy_loading_enabled', '__return_false' );

// Dequeue styles and scripts
function remove_scripts_and_styles () {
    wp_dequeue_style( 'font-awesome-css' );
    wp_dequeue_style( 'mlp_frontend_css' );
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
    wp_dequeue_style( 'wc-blocks-style' );    
    wp_dequeue_style( 'safe-svg-svg-icon-style' );
    wp_dequeue_style( 'gforms_css' );
    wp_deregister_script( 'wp-embed' );
}
add_action( 'wp_enqueue_scripts', 'remove_scripts_and_styles', 9999 );