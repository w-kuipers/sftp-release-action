<?php

/**
 * CPT customs
 */

// Disable single-reviews
//add_action( 'template_redirect', 'dd_redirect_post' );
function dd_redirect_post()
{
	$queried_post_type = get_query_var('post_type');
	if (is_single() && 'location' ==  $queried_post_type) {
		wp_redirect(get_post_type_archive_link('location'), 301);
		exit;
	}
}

// Set amount of posts for review acrhive
//add_action( 'pre_get_posts', 'set_posts_per_page_for_reviews_cpt' );
function set_posts_per_page_for_reviews_cpt($query)
{
	if (!is_admin() && $query->is_main_query()) {

		if (is_post_type_archive('product') || is_post_type_archive('product')) {
			$query->set('post_parent', '0');
		}
	}
}

// Remove the page/1/ from pagination
add_filter('paginate_links', function ($link) {
	$pos = strpos($link, 'page/1/');
	if ($pos !== false) {
		$link = substr($link, 0, $pos);
	}
	return $link;
});

// Calculate the reading time
function calculateReadingTime($content)
{

	// Split content into words
	$words = str_word_count(strip_tags($content));

	// Calculate reading time
	$minutes = round($words / 200);

	// If less than a minute then consider it as one minute
	if ($minutes == 0) {
		return 1;
	} else {
		return $minutes;
	}
}
