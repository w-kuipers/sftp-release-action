<?php

/**
   * Comments customs
*/

// Remove the url field from form
function remove_website_field($fields) {
    unset($fields['url']);
    return $fields;
}
 
add_filter('comment_form_default_fields', 'remove_website_field');