<?php

/**
 * ACF customms
 */

// Enable options page for website
if (function_exists('acf_add_options_page')) {
	$general_options = __("General Options", "dtch");
	$reusable_content = __("Reusable Content", "dtch");

	acf_add_options_page(array(
		"page_title" => $general_options,
		"menu_title" => $general_options,
		"menu_slug" => "general-options",
		"position" => 3

	));

	acf_add_options_page(array(

		"page_title" => $reusable_content,
		"menu_title" => $reusable_content,
		"menu_slug" => "reusable-content",
		"icon_url" => "dashicons-welcome-widgets-menus",
		"position" => 3
	));
}

// Insert background colors into any field named "background_color" 
add_filter('acf/load_field/name=background_color', function ($field) {
	$field['choices'] = array();

	global $background_colors;
	$field["choices"]["default"] = __("-- Choose a background color", "dtch");
	foreach ($background_colors as $key => $value) {
		$field["choices"][$value] = $key;
	}

	return $field;
});

// Insert brand colors into any field named "brand_color" 
add_filter('acf/load_field/name=brand_color', function ($field) {
	$field['choices'] = array();

	global $brand_colors;
	$field["choices"]["default"] = __("-- Choose a brand color", "dtch");
	foreach ($brand_colors as $key => $value) {
		$field["choices"][$value] = $key;
	}

	return $field;
});

// Insert text colors into any field named "text_color" 
add_filter('acf/load_field/name=text_color', function ($field) {
	$field['choices'] = array();

	global $text_colors;
	$field["choices"]["default"] = __("-- Choose a text color", "dtch");
	foreach ($text_colors as $key => $value) {
		$field["choices"][$value] = $key;
	}

	return $field;
});

// Insert image wraps into any field named "image_wrap" 
add_filter('acf/load_field/name=image_wrap', function ($field) {
	$field['choices'] = array();

	global $image_wraps;
	$field["choices"]["default"] = __("-- Choose an image wrap", "dtch");

	foreach ($image_wraps as $key => $value) {
		$field["choices"][$value] = $key;
	}

	return $field;
});


// Insert content wraps into any field named "content_wrap" 
add_filter('acf/load_field/name=content_wrap', function ($field) {

	$field['choices'] = array();

	global $content_wraps;
	$field["choices"]["default"] = __("-- Choose a content wrap", "dtch");
	foreach ($content_wraps as $key => $value) {
		$field["choices"][$value] = $key;
	}

	return $field;
});


// Define custom tn icons
add_filter('acf/load_field/name=dd_icon', 'acf_load_dd_icons_field_choices');
function acf_load_dd_icons_field_choices($field)
{

	// reset choices
	$field['choices'] = [];

	foreach (glob(get_template_directory() . '/assets/img/custom-icons/*.svg') as $file) {
		$field['choices'][basename($file)] = str_replace('.svg', '', basename($file));
	}

	// return the field
	return $field;
}


// Check if text color has to be white on bg color 
function is_white_text($bg_color)
{

	$white_text_array = array('bg-black');

	if (in_array($bg_color, $white_text_array)) {
		return true;
	} else {
		return false;
	}
}


// Remove ACF menu for default users
function hide_acf_menu_for_non_admins()
{

	// Check if the current user is an administrator
	if (!current_user_can('manage_options'))
		remove_menu_page('edit.php?post_type=acf-field-group');
}
add_action('admin_menu', 'hide_acf_menu_for_non_admins');


// Set Google maps API  key for ACF field
if (defined('GOOGLE_MAPS_API_KEY')) {

	function my_acf_init()
	{
		acf_update_setting('google_api_key', GOOGLE_MAPS_API_KEY);
	}

	add_action('acf/init', 'my_acf_init');
}
