<?php 

/**
   * Yoast addons
*/


// Check if current site is production or development and allow to index or not.
add_filter( 'wpseo_robots', 'yoast_seo_index_condition' );

function yoast_seo_index_condition( $robots ) {

	$actual_link = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

	if( strpos( $actual_link, '.test' ) !== false || strpos( $actual_link, '.dd-dev.nl' ) !== false || strpos( $actual_link, '.tn-dev.nl' ) !== false ) {

		return 'noindex, nofollow';

	} else {

		return $robots;
	}
}

// Add custom seperator for Yoast title
add_filter('wpseo_separator_options', function ( $separators ) {
    return ['//'];
}, 10, 1);

// Unhook action for yoast robots.txt
add_action( 'wp_loaded', 'dd_fix_yoast_seo_robots_txt' );
function dd_fix_yoast_seo_robots_txt() {

	global $wp_filter;

	if ( isset( $wp_filter['robots_txt']->callbacks ) && is_array( $wp_filter['robots_txt']->callbacks ) ) {

		foreach ( $wp_filter['robots_txt']->callbacks as $callback_priority => $callback ) {
			
			foreach ( $callback as $function_key => $function ) {

				if ( 'filter_robots' === $function['function'][1] ) {
					unset( $wp_filter['robots_txt']->callbacks[ $callback_priority ][ $function_key ] );
				}

			}

		}

	}

}