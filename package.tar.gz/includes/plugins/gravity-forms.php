<?php

/**
   * Default Gravity forms changes
*/

// Disable Gravity forms CSS
add_filter( 'gform_disable_form_theme_css', '__return_true' );
add_filter( 'gform_disable_css', '__return_true' );

// Change loading icon from Gravity forms
add_filter( 'gform_ajax_spinner_url', 'spinner_url', 10, 2 );
function spinner_url( $image_src, $form ) {
    return get_template_directory_uri() . '/assets/img/loading.svg';
}


// Change submit button on gravity forms
add_filter( 'gform_submit_button', 'form_submit_button', 10, 2);
function form_submit_button( $button, $form ){
    return '<button type="submit" class="button" id="gform_submit_button_' . $form["id"] . '">' . $form["button"]["text"] . '</button>';
}


// Change HTML markup gform validation message
add_filter( 'gform_validation_message', 'dd_validation_message', 10, 2 );
function dd_validation_message( $message, $form ) {    
    return  '<p class="red-color">'. strip_tags( $message ) .'</p>';
    
}


// Remove default legend text in Gravityforms
add_filter( 'gform_required_legend', '__return_empty_string' );