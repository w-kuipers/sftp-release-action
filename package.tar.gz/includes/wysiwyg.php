<?php 

/**
   * Addons for WYSWYG-editor
*/

// Add Admin CSS
add_action( 'after_setup_theme', 'dd_theme_setup' );
if ( ! function_exists( 'dd_theme_setup' ) ) {
    function dd_theme_setup() {
        add_action( 'init', 'dd_mce_buttons' );
    }
}


// Add custom tinymce buttons
if ( ! function_exists( 'dd_mce_buttons' ) ) {
    function dd_mce_buttons() {

        if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
            return;

        if ( get_user_option( 'rich_editing' ) !== 'true' )
            return;

        add_filter( 'mce_external_plugins', 'dd_add_buttons' );
        add_filter( 'mce_buttons', 'dd_register_buttons' );
    }
}


// Register TinyMCE Buttons for shortcodes
if ( ! function_exists( 'dd_add_buttons' ) ) {
    function dd_add_buttons( $plugin_array ) {
        $plugin_array['addbutton'] = get_template_directory_uri() . '/includes/wysiwyg-assets/js/tinymce_buttons.js';
        return $plugin_array;
    }
}
if ( ! function_exists( 'dd_register_buttons' ) ) {
    function dd_register_buttons( $buttons ) {
        array_push( $buttons, 'addbutton' );
        array_push( $buttons, 'addvideobutton' );
        return $buttons;
    }
}


// TinyMCE change button labels
add_action ( 'after_wp_tiny_mce', 'dd_tinymce_extra_vars' );

if ( !function_exists( 'dd_tinymce_extra_vars' ) ) {
    function dd_tinymce_extra_vars() { ?>
        <script type="text/javascript">
            var tinyMCE_object = <?php echo json_encode(
                array(
                    'button_title'          => esc_html__('Add call to action button', 'dtch'),
                    'video_button_title'    => esc_html__('Add embed video', 'dtch')
                )
            ); ?>;
        </script><?php
    }
}


// Add custom styles select button to edirtor
function dd_mce_buttons_2($buttons) {
    array_unshift($buttons, 'styleselect');
    return $buttons;
}
add_filter('mce_buttons_2', 'dd_mce_buttons_2');


// Define the custom styles
function dd_custom_styles( $init_array ) {  

    $style_formats = array(  
        array(  
            'title'     => __('Subtitle', 'dtch'),  
            'block'     => 'span',  
            'classes'   => 'subtitle',
            'wrapper'   => true
        ), 
        array(  
            'title'     => __('Bigger', 'dtch'),  
            'block'     => 'span',  
            'classes'   => 'bigger',
            'wrapper'   => true
        ),
        array(  
            'title'     => __('Smaller', 'dtch'),  
            'block'     => 'span',  
            'classes'   => 'smaller',
            'wrapper'   => true
        )
    );  

    $init_array['style_formats'] = json_encode( $style_formats );     
    return $init_array;  
  
} 
// Attach callback to 'tiny_mce_before_init' 
add_filter( 'tiny_mce_before_init', 'dd_custom_styles' );