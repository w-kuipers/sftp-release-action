<?php
    
/**
   * Custom role capabilities
*/

function dd_add_custom_user_role() {
    add_role(
        __('webmaster', 'dtch'),
        __('Webmaster', 'dtch'),
        array(
            'read' => true,
            'edit_posts' => true,
            'delete_posts' => true,
            'publish_posts' => true,
            'upload_files' => true,
        )
    );
}
add_action('init', 'dd_add_custom_user_role');


function add_capability_to_webmaster() {

    $role = get_role('webmaster');

    // Add and define capacities
    $role->add_cap('moderate_comments');
    $role->add_cap('manage_categories');
    $role->add_cap('manage_links');
    $role->add_cap('upload_files');
    $role->add_cap('unfiltered_html');
    $role->add_cap('edit_posts');
    $role->add_cap('edit_others_posts');
    $role->add_cap('edit_published_posts');
    $role->add_cap('publish_posts');
    $role->add_cap('edit_pages');
    $role->add_cap('read');
    $role->add_cap('edit_others_pages');
    $role->add_cap('edit_published_pages');
    $role->add_cap('publish_pages');
    $role->add_cap('delete_pages');
    $role->add_cap('delete_others_pages');
    $role->add_cap('delete_published_pages');
    $role->add_cap('delete_posts');
    $role->add_cap('delete_others_posts');
    $role->add_cap('delete_published_posts');
    $role->add_cap('delete_private_posts');
    $role->add_cap('edit_private_posts');
    $role->add_cap('read_private_posts');
    $role->add_cap('delete_private_pages');
    $role->add_cap('edit_private_pages');
    $role->add_cap('read_private_pages');
    $role->add_cap('unfiltered_upload');
    $role->add_cap('edit_dashboard');
    $role->add_cap('export');
    $role->add_cap('wpseo_manage_options');
    $role->add_cap('copy_posts');

    // Woo roles
    $role->add_cap('manage_woocommerce');
    $role->add_cap('view_woocommerce_reports');
    $role->add_cap('edit_product');
    $role->add_cap('read_product');
    $role->add_cap('delete_product');
    $role->add_cap('edit_products');
    $role->add_cap('edit_others_products');
    $role->add_cap('publish_products');
    $role->add_cap('read_private_products');
    $role->add_cap('delete_products');
    $role->add_cap('delete_private_products');
    $role->add_cap('delete_published_products');
    $role->add_cap('delete_others_products');
    $role->add_cap('edit_private_products');
    $role->add_cap('edit_published_products');
    $role->add_cap('manage_product_terms');
    $role->add_cap('edit_product_terms');
    $role->add_cap('delete_product_terms');
    $role->add_cap('assign_product_terms');
    $role->add_cap('edit_shop_order');
    $role->add_cap('read_shop_order');
    $role->add_cap('delete_shop_order');
    $role->add_cap('edit_shop_orders');
    $role->add_cap('edit_others_shop_orders');
    $role->add_cap('publish_shop_orders');
    $role->add_cap('read_private_shop_orders');
    $role->add_cap('delete_shop_orders');
    $role->add_cap('delete_private_shop_orders');
    $role->add_cap('delete_published_shop_orders');
    $role->add_cap('delete_others_shop_orders');
    $role->add_cap('edit_private_shop_orders');
    $role->add_cap('edit_published_shop_orders');
    $role->add_cap('manage_shop_order_terms');
    $role->add_cap('edit_shop_order_terms');
    $role->add_cap('delete_shop_order_terms');
    $role->add_cap('assign_shop_order_terms');
    $role->add_cap('edit_shop_coupon');
    $role->add_cap('read_shop_coupon');
    $role->add_cap('delete_shop_coupon');
    $role->add_cap('edit_shop_coupons');
    $role->add_cap('edit_others_shop_coupons');
    $role->add_cap('publish_shop_coupons');
    $role->add_cap('read_private_shop_coupons');
    $role->add_cap('delete_shop_coupons');
    $role->add_cap('delete_private_shop_coupons');
    $role->add_cap('delete_published_shop_coupons');
    $role->add_cap('delete_others_shop_coupons');
    $role->add_cap('edit_private_shop_coupons');
    $role->add_cap('edit_published_shop_coupons');
    $role->add_cap('manage_shop_coupon_terms');
    $role->add_cap('edit_shop_coupon_terms');
    $role->add_cap('delete_shop_coupon_terms');
    $role->add_cap('assign_shop_coupon_terms');
    $role->add_cap('edit_theme_options');
	$role->add_cap('gravityforms_edit_forms');
	$role->add_cap('gravityforms_edit_settings');
	$role->add_cap('gravityforms_view_settings');

    // Remove specific capacities
    $role->remove_cap('list_users');
    $role->remove_cap('manage_options');
    $role->remove_cap('activate_plugins');

	

}
add_action('init', 'add_capability_to_webmaster');


// Remove items from admin menu
function remove_menus() {

    if( !current_user_can('administrator') ) {
        remove_menu_page( 'activity-log-page' ); 
    }
}
add_action('admin_menu', 'remove_menus', 999);