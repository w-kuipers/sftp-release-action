<?php

// Available background colors for ACF "background_color" fields
global $background_colors;
$background_colors = array(
	"White" => "bg-white"
);

// Available text colors for ACF "text_color" fields
global $text_colors;
$text_colors = array();

// Available brand colors for ACF "brand_color" fields
global $brand_colors;
$brand_colors = array(
	"Blauw" => "brand-blue",
	"Groen" => "brand-green",
	"Oranje" => "brand-orange",
	"Paars" => "brand-purple"
);

// Available image wraps for ACF "image_wrap" fields
global $image_wraps;
$image_wraps = array();

// Available content wraps for ACF "content_wrap" fields
global $content_wraps;
$content_wraps = array();
